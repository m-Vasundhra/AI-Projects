import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API routes
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // AI Tax Advisory Route
  app.post("/api/ai-tax-advisor", async (req, res) => {
    try {
      const apiKey = process.env.GEMINI_API_KEY;
      if (!apiKey) {
        return res.status(400).json({
          error: "GEMINI_API_KEY is missing. Please add your GEMINI_API_KEY in secrets/env to enable AI Tax Assistant.",
        });
      }

      const { userProfile, oldRegimeResult, newRegimeResult, userQuestion } = req.body;

      const ai = new GoogleGenAI({ apiKey });

      const prompt = `You are an expert Indian Chartered Accountant (CA) and Certified Financial Planner specializing in Income Tax Laws under the Indian Income Tax Act, 1961 (FY 2024-25 & FY 2025-26 Budget updates).

User's Financial Profile:
- Age Category: ${userProfile.ageGroup}
- Financial Year: ${userProfile.financialYear}
- Employment Type: ${userProfile.employmentType}
- Gross Salary Income: ₹${(userProfile.grossSalary || 0).toLocaleString('en-IN')}
- Basic Salary: ₹${(userProfile.basicSalary || 0).toLocaleString('en-IN')}
- HRA Received: ₹${(userProfile.hraReceived || 0).toLocaleString('en-IN')}
- Actual Rent Paid: ₹${(userProfile.rentPaid || 0).toLocaleString('en-IN')} (${userProfile.isMetro ? 'Metro City' : 'Non-Metro City'})
- Income from Other Sources (Interest, Dividends, etc.): ₹${(userProfile.otherIncome || 0).toLocaleString('en-IN')}
- Home Loan Interest (Sec 24b): ₹${(userProfile.homeLoanInterest || 0).toLocaleString('en-IN')}
- Deductions claimed under Sec 80C: ₹${(userProfile.sec80C || 0).toLocaleString('en-IN')} / Max ₹1,50,000
- Deductions under Sec 80D (Health): ₹${(userProfile.sec80D || 0).toLocaleString('en-IN')}
- Employee NPS Sec 80CCD(1B): ₹${(userProfile.sec80CCD1B || 0).toLocaleString('en-IN')} / Max ₹50,000
- Employer NPS Sec 80CCD(2): ₹${(userProfile.sec80CCD2 || 0).toLocaleString('en-IN')}
- Savings Bank Interest Sec 80TTA/TTB: ₹${(userProfile.sec80TTA || 0).toLocaleString('en-IN')}
- Other Deductions (80G, 80E, etc.): ₹${(userProfile.otherDeductions || 0).toLocaleString('en-IN')}

Tax Computation Summary:
- Old Tax Regime Net Taxable Income: ₹${(oldRegimeResult.taxableIncome || 0).toLocaleString('en-IN')} | Total Tax Payable: ₹${(oldRegimeResult.totalTaxPayable || 0).toLocaleString('en-IN')}
- New Tax Regime Net Taxable Income: ₹${(newRegimeResult.taxableIncome || 0).toLocaleString('en-IN')} | Total Tax Payable: ₹${(newRegimeResult.totalTaxPayable || 0).toLocaleString('en-IN')}
- Recommended Optimal Regime: ${newRegimeResult.totalTaxPayable < oldRegimeResult.totalTaxPayable ? 'NEW REGIME' : oldRegimeResult.totalTaxPayable < newRegimeResult.totalTaxPayable ? 'OLD REGIME' : 'EITHER (Equal tax)'}
- Tax Savings Difference: ₹${Math.abs(oldRegimeResult.totalTaxPayable - newRegimeResult.totalTaxPayable).toLocaleString('en-IN')}

${userQuestion ? `User's Specific Query: "${userQuestion}"` : 'Please provide actionable tax optimization advice for this profile.'}

Instructions for output:
1. Provide a concise executive summary comparing Old vs New regime for this specific user.
2. Highlight key missed tax saving opportunities (e.g., untapped 80CCD(1B) NPS ₹50k, 80D parent health insurance, restructuring special allowance into food coupons or LTA, corporate NPS under 80CCD(2), or switching regimes).
3. If Old Regime is close to New Regime, state the exact additional deductions needed to make Old Regime better.
4. Give actionable, compliant, practical steps in clear Indian English with Rupee symbols (₹).
5. Format nicely with markdown headers, bullet points, and bold text. Keep it professional, friendly, and structured.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: prompt,
      });

      const text = response.text || "No guidance returned.";
      return res.json({ advice: text });
    } catch (err: any) {
      console.error("AI Tax Advisor Error:", err);
      return res.status(500).json({ error: err.message || "Failed to generate tax advice." });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Indian Tax Calculator server listening on http://0.0.0.0:${PORT}`);
  });
}

startServer();
