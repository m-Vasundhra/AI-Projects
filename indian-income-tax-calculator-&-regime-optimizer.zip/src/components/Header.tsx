import React from 'react';
import { FinancialYear } from '../types';
import { PRESET_PROFILES, PresetProfile } from '../data/presets';
import { Calculator, Sparkles, FileText, HelpCircle, Layers } from 'lucide-react';

interface HeaderProps {
  financialYear: FinancialYear;
  onSelectYear: (year: FinancialYear) => void;
  onSelectPreset: (preset: PresetProfile) => void;
  onOpenHraModal: () => void;
  onOpenReportModal: () => void;
  activeTab: 'calculator' | 'guide';
  setActiveTab: (tab: 'calculator' | 'guide') => void;
}

export const Header: React.FC<HeaderProps> = ({
  financialYear,
  onSelectYear,
  onSelectPreset,
  onOpenHraModal,
  onOpenReportModal,
  activeTab,
  setActiveTab,
}) => {
  return (
    <header className="bg-slate-900 text-white border-b border-slate-800 sticky top-0 z-30 shadow-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Logo & Title */}
          <div className="flex items-center space-x-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-emerald-500 to-teal-400 flex items-center justify-center text-slate-950 font-bold shadow-lg shadow-emerald-500/20">
              <Calculator className="w-5 h-5 text-slate-950" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-xl font-bold tracking-tight text-white">TaxRegime India</h1>
                <span className="bg-emerald-500/20 text-emerald-400 text-xs px-2.5 py-0.5 rounded-full font-medium border border-emerald-500/30">
                  FY {financialYear}
                </span>
              </div>
              <p className="text-xs text-slate-400">Old vs New Income Tax Regime Optimizer</p>
            </div>
          </div>

          {/* Navigation Controls & Year Selection */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-3">
            
            {/* FY Selector */}
            <div className="flex items-center bg-slate-800/80 p-1 rounded-lg border border-slate-700">
              <span className="text-xs text-slate-400 px-2 font-medium hidden sm:inline">FY:</span>
              {(['2024-25', '2025-26', '2023-24'] as FinancialYear[]).map((fy) => (
                <button
                  key={fy}
                  onClick={() => onSelectYear(fy)}
                  className={`text-xs px-2.5 py-1 rounded-md font-medium transition-all ${
                    financialYear === fy
                      ? 'bg-emerald-500 text-slate-950 font-semibold shadow-sm'
                      : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                  }`}
                >
                  {fy}
                </button>
              ))}
            </div>

            {/* View Switcher */}
            <div className="flex items-center bg-slate-800/80 p-1 rounded-lg border border-slate-700">
              <button
                onClick={() => setActiveTab('calculator')}
                className={`flex items-center space-x-1.5 text-xs px-3 py-1 rounded-md font-medium transition-all ${
                  activeTab === 'calculator'
                    ? 'bg-slate-700 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <Layers className="w-3.5 h-3.5" />
                <span>Calculator</span>
              </button>
              <button
                onClick={() => setActiveTab('guide')}
                className={`flex items-center space-x-1.5 text-xs px-3 py-1 rounded-md font-medium transition-all ${
                  activeTab === 'guide'
                    ? 'bg-slate-700 text-white shadow-sm'
                    : 'text-slate-400 hover:text-white'
                }`}
              >
                <HelpCircle className="w-3.5 h-3.5" />
                <span>Slab Matrix</span>
              </button>
            </div>

            {/* Utility Buttons */}
            <button
              onClick={onOpenHraModal}
              className="flex items-center space-x-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
              title="HRA Exemption Calculator"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
              <span className="hidden sm:inline">HRA Calc</span>
            </button>

            <button
              onClick={onOpenReportModal}
              className="flex items-center space-x-1 text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-3 py-1.5 rounded-lg shadow-sm transition-colors"
            >
              <FileText className="w-3.5 h-3.5" />
              <span>Tax Report</span>
            </button>
          </div>

        </div>

        {/* Quick Presets Bar */}
        <div className="mt-3 pt-2.5 border-t border-slate-800 flex items-center space-x-2 overflow-x-auto pb-1 text-xs scrollbar-none">
          <span className="text-slate-400 font-medium shrink-0 flex items-center">
            Presets:
          </span>
          {PRESET_PROFILES.map((preset) => (
            <button
              key={preset.id}
              onClick={() => onSelectPreset(preset)}
              className="shrink-0 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-700/60 hover:border-slate-600 px-2.5 py-1 rounded-full text-xs transition-all flex items-center space-x-1.5"
            >
              <span>{preset.label}</span>
              <span className="text-[10px] bg-slate-700 text-emerald-400 px-1.5 py-0.2 rounded-full font-mono">
                {preset.badge}
              </span>
            </button>
          ))}
        </div>

      </div>
    </header>
  );
};
