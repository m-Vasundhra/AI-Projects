import React, { useState } from 'react';
import { TaxInputs } from '../types';
import { Shield, ChevronDown, ChevronUp, PlusCircle, CheckCircle, Info } from 'lucide-react';

interface DeductionsFormProps {
  inputs: TaxInputs;
  onChange: (key: keyof TaxInputs, value: any) => void;
}

export const DeductionsForm: React.FC<DeductionsFormProps> = ({ inputs, onChange }) => {
  const [show80CChecklist, setShow80CChecklist] = useState(false);
  const [sec80cItems, setSec80cItems] = useState({
    epf: 0,
    ppf: 0,
    elss: 0,
    insurance: 0,
    homeLoanPrincipal: 0,
    tuitionFee: 0,
    taxFd: 0,
  });

  const handle80CItemChange = (item: keyof typeof sec80cItems, value: number) => {
    const updated = { ...sec80cItems, [item]: value };
    setSec80cItems(updated);
    const sum = Object.values(updated).reduce((acc, curr) => acc + curr, 0);
    onChange('sec80C', Math.min(150000, sum));
  };

  const isSenior = inputs.ageGroup === 'senior60' || inputs.ageGroup === 'superSenior80';

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6 text-white">
      
      {/* Section Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-blue-500/10 text-blue-400">
            <Shield className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Tax Deductions & Exemptions (Old Regime)</h3>
            <p className="text-xs text-slate-400">Deductions lower your taxable income under the Old Regime</p>
          </div>
        </div>
        <span className="text-xs bg-slate-800 text-blue-400 font-mono px-2.5 py-1 rounded-full border border-slate-700">
          Claimed: ₹{(
            (inputs.sec80C || 0) +
            (inputs.sec80D_self || 0) +
            (inputs.sec80D_parents || 0) +
            (inputs.sec80CCD1B || 0) +
            (inputs.sec80CCD2 || 0) +
            (inputs.sec80TTA || 0) +
            (inputs.sec80E || 0) +
            (inputs.sec80G || 0) +
            (inputs.professionalTax || 0)
          ).toLocaleString('en-IN')}
        </span>
      </div>

      {/* 80C Deduction Card */}
      <div className="p-4 rounded-xl bg-slate-800/60 border border-slate-700 space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <label className="text-sm font-bold text-white flex items-center space-x-2">
              <span>Section 80C (PPF, EPF, ELSS, Insurance)</span>
              <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2 py-0.5 rounded font-mono">
                Max ₹1.5 Lakh
              </span>
            </label>
            <p className="text-xs text-slate-400">PF, ELSS mutual funds, LIC premium, Home loan principal, School fees</p>
          </div>
          <button
            type="button"
            onClick={() => setShow80CChecklist(!show80CChecklist)}
            className="text-xs text-blue-400 hover:text-blue-300 flex items-center space-x-1 underline"
          >
            <span>{show80CChecklist ? 'Hide Breakdown' : '80C Calculator'}</span>
            {show80CChecklist ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
          </button>
        </div>

        {/* 80C Direct Amount Input */}
        <div className="relative">
          <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">₹</span>
          <input
            type="number"
            min="0"
            max="150000"
            value={inputs.sec80C || ''}
            onChange={(e) => onChange('sec80C', Math.min(150000, Number(e.target.value)))}
            placeholder="e.g. 150000"
            className="w-full bg-slate-900 border border-slate-700 rounded-xl pl-7 pr-3 py-2 text-sm text-white font-mono focus:outline-none focus:border-blue-500 font-semibold"
          />
        </div>

        {/* Optional 80C Helper Breakdown Drawer */}
        {show80CChecklist && (
          <div className="mt-3 p-3 bg-slate-900/90 rounded-lg border border-slate-700/80 space-y-2 text-xs">
            <div className="font-semibold text-slate-300">Sum up individual investments:</div>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <div>
                <span className="text-slate-400">EPF / PF:</span>
                <input
                  type="number"
                  value={sec80cItems.epf || ''}
                  onChange={(e) => handle80CItemChange('epf', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
              <div>
                <span className="text-slate-400">PPF:</span>
                <input
                  type="number"
                  value={sec80cItems.ppf || ''}
                  onChange={(e) => handle80CItemChange('ppf', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
              <div>
                <span className="text-slate-400">ELSS Mutual Funds:</span>
                <input
                  type="number"
                  value={sec80cItems.elss || ''}
                  onChange={(e) => handle80CItemChange('elss', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
              <div>
                <span className="text-slate-400">Life Insurance (LIC):</span>
                <input
                  type="number"
                  value={sec80cItems.insurance || ''}
                  onChange={(e) => handle80CItemChange('insurance', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
              <div>
                <span className="text-slate-400">Home Loan Principal:</span>
                <input
                  type="number"
                  value={sec80cItems.homeLoanPrincipal || ''}
                  onChange={(e) => handle80CItemChange('homeLoanPrincipal', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
              <div>
                <span className="text-slate-400">Tuition Fees:</span>
                <input
                  type="number"
                  value={sec80cItems.tuitionFee || ''}
                  onChange={(e) => handle80CItemChange('tuitionFee', Number(e.target.value))}
                  placeholder="0"
                  className="w-full bg-slate-800 border border-slate-700 rounded p-1 text-white font-mono mt-0.5"
                />
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Grid of Other Deductions */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Section 80D - Health Insurance (Self & Family) */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>80D Health Insurance (Self & Family)</span>
            <span className="text-[10px] text-blue-400 font-mono">Max ₹{isSenior ? '50k' : '25k'}</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              max={isSenior ? 50000 : 25000}
              value={inputs.sec80D_self || ''}
              onChange={(e) => onChange('sec80D_self', Number(e.target.value))}
              placeholder={`Max ₹${isSenior ? '50,000' : '25,000'}`}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">Includes ₹5,000 preventive checkup</span>
        </div>

        {/* Section 80D - Health Insurance (Parents) */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>80D Health Insurance (Parents)</span>
            <span className="text-[10px] text-blue-400 font-mono">Max ₹50k</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              max="50000"
              value={inputs.sec80D_parents || ''}
              onChange={(e) => onChange('sec80D_parents', Number(e.target.value))}
              placeholder="e.g. 25000 or 50000"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">₹25k for parents &lt;60, ₹50k for senior parents</span>
        </div>

        {/* Employee NPS Sec 80CCD(1B) */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>Section 80CCD(1B) - Employee NPS</span>
            <span className="text-[10px] text-emerald-400 font-mono">Max ₹50k Extra</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              max="50000"
              value={inputs.sec80CCD1B || ''}
              onChange={(e) => onChange('sec80CCD1B', Number(e.target.value))}
              placeholder="e.g. 50000"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">Exclusive deduction over and above 80C limit</span>
        </div>

        {/* Employer NPS Sec 80CCD(2) */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>Section 80CCD(2) - Corporate NPS</span>
            <span className="text-[10px] text-amber-400 font-mono">Both Regimes!</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              value={inputs.sec80CCD2 || ''}
              onChange={(e) => onChange('sec80CCD2', Number(e.target.value))}
              placeholder="Up to 10% or 14% of Basic"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">Employer contribution allowed in both Old & New regimes</span>
        </div>

        {/* Section 80TTA / 80TTB */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>{isSenior ? 'Section 80TTB (Senior Interest)' : 'Section 80TTA (Savings Interest)'}</span>
            <span className="text-[10px] text-blue-400 font-mono">Max ₹{isSenior ? '50k' : '10k'}</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              max={isSenior ? 50000 : 10000}
              value={inputs.sec80TTA || ''}
              onChange={(e) => onChange('sec80TTA', Number(e.target.value))}
              placeholder={`Max ₹${isSenior ? '50,000' : '10,000'}`}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">Deduction on bank savings account interest</span>
        </div>

        {/* Professional Tax */}
        <div className="space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
          <label className="text-xs font-semibold text-slate-200 flex items-center justify-between">
            <span>Professional Tax / LTA</span>
            <span className="text-[10px] text-slate-400 font-mono">Max ₹2,500</span>
          </label>
          <div className="relative">
            <span className="absolute left-3 top-2 text-slate-400 text-xs">₹</span>
            <input
              type="number"
              min="0"
              max="2500"
              value={inputs.professionalTax || ''}
              onChange={(e) => onChange('professionalTax', Number(e.target.value))}
              placeholder="e.g. 2400"
              className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-3 py-1.5 text-xs text-white font-mono"
            />
          </div>
          <span className="text-[10px] text-slate-400 block">Deducted directly from salary by state govts</span>
        </div>

      </div>

    </div>
  );
};
