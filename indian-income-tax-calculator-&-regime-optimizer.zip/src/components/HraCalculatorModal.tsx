import React from 'react';
import { X, Sparkles, Home, CheckCircle2, AlertCircle } from 'lucide-react';
import { calculateHraExemption } from '../utils/taxCalculator';

interface HraCalculatorModalProps {
  isOpen: boolean;
  onClose: () => void;
  basicSalary: number;
  hraReceived: number;
  rentPaid: number;
  isMetro: boolean;
  onApplyHra: (hra: number, rent: number, metro: boolean) => void;
}

export const HraCalculatorModal: React.FC<HraCalculatorModalProps> = ({
  isOpen,
  onClose,
  basicSalary: initialBasic,
  hraReceived: initialHra,
  rentPaid: initialRent,
  isMetro: initialMetro,
  onApplyHra,
}) => {
  const [basic, setBasic] = React.useState(initialBasic || 600000);
  const [hra, setHra] = React.useState(initialHra || 240000);
  const [rent, setRent] = React.useState(initialRent || 216000);
  const [metro, setMetro] = React.useState(initialMetro);

  if (!isOpen) return null;

  // Clause 1: Actual HRA Received
  const clause1 = hra;
  // Clause 2: Rent paid - 10% of Basic Salary
  const clause2 = Math.max(0, rent - 0.10 * basic);
  // Clause 3: 50% (Metro) or 40% (Non-Metro) of Basic Salary
  const clause3 = (metro ? 0.50 : 0.40) * basic;

  const hraExemption = Math.max(0, Math.min(clause1, clause2, clause3));
  const taxableHra = Math.max(0, hra - hraExemption);

  const handleApply = () => {
    onApplyHra(hra, rent, metro);
    onClose();
  };

  const formatRupee = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden text-white space-y-5 p-6">
        
        {/* Header */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div className="flex items-center space-x-2">
            <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
              <Home className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-base font-bold text-white">HRA Exemption Calculator</h3>
              <p className="text-xs text-slate-400">Under Section 10(13A) Rule 2A</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Inputs */}
        <div className="space-y-3 text-xs">
          
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Basic Salary (Annual)</label>
              <input
                type="number"
                value={basic || ''}
                onChange={(e) => setBasic(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 font-mono text-white text-xs"
              />
            </div>
            <div>
              <label className="text-slate-300 font-medium block mb-1">HRA Received (Annual)</label>
              <input
                type="number"
                value={hra || ''}
                onChange={(e) => setHra(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 font-mono text-white text-xs"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="text-slate-300 font-medium block mb-1">Rent Paid (Annual)</label>
              <input
                type="number"
                value={rent || ''}
                onChange={(e) => setRent(Number(e.target.value))}
                className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2 font-mono text-white text-xs"
              />
            </div>
            <div>
              <label className="text-slate-300 font-medium block mb-1">City Type</label>
              <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-800 rounded-lg border border-slate-700">
                <button
                  type="button"
                  onClick={() => setMetro(true)}
                  className={`py-1.5 rounded text-[11px] font-medium ${
                    metro ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
                  }`}
                >
                  Metro (50%)
                </button>
                <button
                  type="button"
                  onClick={() => setMetro(false)}
                  className={`py-1.5 rounded text-[11px] font-medium ${
                    !metro ? 'bg-amber-500 text-slate-950 font-bold' : 'text-slate-400'
                  }`}
                >
                  Non-Metro (40%)
                </button>
              </div>
            </div>
          </div>

        </div>

        {/* 3-Clause Rule Comparison */}
        <div className="bg-slate-800/60 p-4 rounded-xl border border-slate-700 space-y-2 text-xs">
          <div className="font-bold text-slate-200 border-b border-slate-700 pb-1.5 flex items-center justify-between">
            <span>Minimum of 3 Legal Clauses Applies:</span>
            <span className="text-amber-400 text-[11px]">Rule 2A</span>
          </div>

          <div className="space-y-1.5 font-mono text-slate-300">
            <div className={`flex items-center justify-between p-1.5 rounded ${hraExemption === clause1 ? 'bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30' : ''}`}>
              <span>1. Actual HRA Received:</span>
              <span>{formatRupee(clause1)}</span>
            </div>
            <div className={`flex items-center justify-between p-1.5 rounded ${hraExemption === clause2 ? 'bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30' : ''}`}>
              <span>2. Rent Paid - 10% of Basic:</span>
              <span>{formatRupee(clause2)}</span>
            </div>
            <div className={`flex items-center justify-between p-1.5 rounded ${hraExemption === clause3 ? 'bg-amber-500/10 text-amber-300 font-bold border border-amber-500/30' : ''}`}>
              <span>3. {metro ? '50%' : '40%'} of Basic Salary:</span>
              <span>{formatRupee(clause3)}</span>
            </div>
          </div>
        </div>

        {/* Calculation Result */}
        <div className="bg-emerald-950/60 border border-emerald-500/40 p-4 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-emerald-300 font-medium">Eligible HRA Exemption</span>
            <div className="text-xl font-extrabold text-emerald-400 font-mono">
              {formatRupee(hraExemption)}
            </div>
            <span className="text-[11px] text-slate-400">
              Taxable HRA portion: <span className="text-slate-200 font-mono">{formatRupee(taxableHra)}</span>
            </span>
          </div>

          <button
            onClick={handleApply}
            className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold px-4 py-2 rounded-xl text-xs shadow transition-colors"
          >
            Apply to Form
          </button>
        </div>

      </div>
    </div>
  );
};
