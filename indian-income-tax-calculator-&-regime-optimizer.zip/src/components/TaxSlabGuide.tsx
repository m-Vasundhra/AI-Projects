import React, { useState } from 'react';
import { BookOpen, Check, HelpCircle, ChevronDown, ChevronUp } from 'lucide-react';

export const TaxSlabGuide: React.FC = () => {
  const [openFaq, setOpenFaq] = useState<number | null>(0);

  const FAQS = [
    {
      q: 'Which regime is selected by default in ITR filing?',
      a: 'Starting Financial Year 2023-24 onwards, the New Tax Regime is the DEFAULT tax regime. Salaried employees can choose between Old and New Regime at the time of filing ITR or submitting Form 12BB to their employer.',
    },
    {
      q: 'Can salaried employees switch between Old and New Tax Regime every year?',
      a: 'Yes! Salaried individuals (without business/professional income) can freely choose or switch between the Old Regime and New Regime every financial year depending on which gives higher tax savings.',
    },
    {
      q: 'What standard deduction is available in FY 2024-25 and FY 2025-26?',
      a: 'Under Budget 2024 revisions, salaried employees and pensioners get a Standard Deduction of ₹75,000 under the New Tax Regime (increased from ₹50,000). Under the Old Tax Regime, standard deduction remains ₹50,000.',
    },
    {
      q: 'How does Section 87A rebate work under both regimes?',
      a: 'Under New Regime: Full rebate up to ₹25,000 tax if taxable income is <= ₹7,00,000 (effectively ₹0 tax up to ₹7.75 Lakhs salary after ₹75k standard deduction). Under Old Regime: Full rebate up to ₹12,500 tax if taxable income is <= ₹5,00,000 (effectively ₹0 tax up to ₹5.5 Lakhs salary).',
    },
    {
      q: 'Which deductions are allowed under the New Tax Regime?',
      a: 'New Tax Regime disallows major deductions like 80C, 80D, HRA, LTA, and Home Loan interest for self-occupied property. HOWEVER, it allows: 1) Standard Deduction (₹75,000), 2) Employer NPS contribution u/s 80CCD(2) (up to 14% of Basic), and 3) Transport allowance for specially-abled individuals.',
    },
  ];

  return (
    <div className="space-y-6 text-white max-w-5xl mx-auto">
      
      {/* Overview Banner */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-6 space-y-3">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <BookOpen className="w-5 h-5" />
          </div>
          <h2 className="text-xl font-bold text-white">Indian Income Tax Slab Matrix Guide (FY 2024-25 / FY 2025-26)</h2>
        </div>
        <p className="text-xs text-slate-300 leading-relaxed">
          Comprehensive reference guide comparing tax brackets, Section 87A rebates, surcharge limits, and allowed deductions under both Indian Income Tax Regimes.
        </p>
      </div>

      {/* Side by Side Slab Tables */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* New Regime Slabs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-emerald-400">New Tax Regime Slabs (Default)</h3>
            <span className="text-[11px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded font-mono">Budget 2024</span>
          </div>

          <table className="w-full text-xs text-left font-mono">
            <thead className="bg-slate-800 text-slate-400 text-[11px] uppercase">
              <tr>
                <th className="py-2 px-3">Income Slab</th>
                <th className="py-2 px-3 text-right">Tax Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              <tr><td className="py-2 px-3 font-sans">Up to ₹3,00,000</td><td className="py-2 px-3 text-right font-bold text-emerald-400">0% (NIL)</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹3,00,001 - ₹7,00,000</td><td className="py-2 px-3 text-right">5%</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹7,00,001 - ₹10,00,000</td><td className="py-2 px-3 text-right">10%</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹10,00,001 - ₹12,00,000</td><td className="py-2 px-3 text-right">15%</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹12,00,001 - ₹15,00,000</td><td className="py-2 px-3 text-right">20%</td></tr>
              <tr><td className="py-2 px-3 font-sans">Above ₹15,00,000</td><td className="py-2 px-3 text-right text-rose-400 font-bold">30%</td></tr>
            </tbody>
          </table>

          <div className="text-[11px] text-slate-400 space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <div><strong className="text-slate-200">Standard Deduction:</strong> ₹75,000 for Salaried</div>
            <div><strong className="text-slate-200">Rebate Sec 87A:</strong> Income up to ₹7.0 Lakh gets tax free</div>
            <div><strong className="text-slate-200">Surcharge Cap:</strong> Capped at 25% (previously 37%)</div>
          </div>
        </div>

        {/* Old Regime Slabs */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h3 className="text-sm font-bold text-blue-400">Old Tax Regime Slabs (Below 60 yrs)</h3>
            <span className="text-[11px] bg-blue-500/20 text-blue-300 px-2 py-0.5 rounded font-mono">Deductions Allowed</span>
          </div>

          <table className="w-full text-xs text-left font-mono">
            <thead className="bg-slate-800 text-slate-400 text-[11px] uppercase">
              <tr>
                <th className="py-2 px-3">Income Slab</th>
                <th className="py-2 px-3 text-right">Tax Rate</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300">
              <tr><td className="py-2 px-3 font-sans">Up to ₹2,50,000</td><td className="py-2 px-3 text-right font-bold text-blue-400">0% (NIL)</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹2,50,001 - ₹5,00,000</td><td className="py-2 px-3 text-right">5%</td></tr>
              <tr><td className="py-2 px-3 font-sans">₹5,00,001 - ₹10,00,000</td><td className="py-2 px-3 text-right">20%</td></tr>
              <tr><td className="py-2 px-3 font-sans">Above ₹10,00,000</td><td className="py-2 px-3 text-right text-rose-400 font-bold">30%</td></tr>
            </tbody>
          </table>

          <div className="text-[11px] text-slate-400 space-y-1 bg-slate-800/40 p-3 rounded-xl border border-slate-800">
            <div><strong className="text-slate-200">Standard Deduction:</strong> ₹50,000 for Salaried</div>
            <div><strong className="text-slate-200">Rebate Sec 87A:</strong> Income up to ₹5.0 Lakh gets tax free</div>
            <div><strong className="text-slate-200">Exemptions:</strong> 80C, 80D, HRA, LTA, Home Loan 24b allowed</div>
          </div>
        </div>

      </div>

      {/* Deductions Cheat Sheet Table */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white">Popular Tax Deduction Limits (Chapter VI-A)</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-xs text-left">
            <thead className="bg-slate-800 text-slate-300 font-semibold uppercase">
              <tr>
                <th className="py-2.5 px-3">Section</th>
                <th className="py-2.5 px-3">Investment / Expense Description</th>
                <th className="py-2.5 px-3 font-mono">Maximum Limit</th>
                <th className="py-2.5 px-3">Regime Applicability</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800 text-slate-300 font-mono">
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 80C</td>
                <td className="py-2.5 px-3 font-sans">EPF, PPF, ELSS, LIC, Home Loan Principal, Tuition Fee</td>
                <td className="py-2.5 px-3">₹1,50,000</td>
                <td className="py-2.5 px-3 font-sans text-blue-400">Old Regime Only</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 80D</td>
                <td className="py-2.5 px-3 font-sans">Health Insurance for Self, Family & Parents</td>
                <td className="py-2.5 px-3">₹25,000 to ₹1,00,000</td>
                <td className="py-2.5 px-3 font-sans text-blue-400">Old Regime Only</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 80CCD(1B)</td>
                <td className="py-2.5 px-3 font-sans">Additional Employee Contribution to NPS</td>
                <td className="py-2.5 px-3">₹50,000 (Extra)</td>
                <td className="py-2.5 px-3 font-sans text-blue-400">Old Regime Only</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 80CCD(2)</td>
                <td className="py-2.5 px-3 font-sans">Employer Contribution to NPS</td>
                <td className="py-2.5 px-3">14% or 10% of Basic</td>
                <td className="py-2.5 px-3 font-sans text-emerald-400 font-bold">Both Regimes!</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 24(b)</td>
                <td className="py-2.5 px-3 font-sans">Home Loan Interest (Self Occupied Property)</td>
                <td className="py-2.5 px-3">₹2,00,000</td>
                <td className="py-2.5 px-3 font-sans text-blue-400">Old Regime Only</td>
              </tr>
              <tr>
                <td className="py-2.5 px-3 font-bold text-emerald-400 font-sans">Sec 80TTA / 80TTB</td>
                <td className="py-2.5 px-3 font-sans">Savings Interest (Normal) / FD & Deposit Interest (Senior)</td>
                <td className="py-2.5 px-3">₹10,000 / ₹50,000</td>
                <td className="py-2.5 px-3 font-sans text-blue-400">Old Regime Only</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>

      {/* Frequently Asked Questions */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 space-y-3">
        <h3 className="text-sm font-bold text-white flex items-center space-x-2">
          <HelpCircle className="w-4 h-4 text-emerald-400" />
          <span>Frequently Asked Tax Questions</span>
        </h3>

        <div className="space-y-2">
          {FAQS.map((faq, idx) => (
            <div key={idx} className="border border-slate-800 rounded-xl overflow-hidden">
              <button
                onClick={() => setOpenFaq(openFaq === idx ? null : idx)}
                className="w-full text-left p-3.5 bg-slate-800/40 hover:bg-slate-800/70 text-xs font-semibold text-slate-200 flex items-center justify-between"
              >
                <span>{faq.q}</span>
                {openFaq === idx ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>
              {openFaq === idx && (
                <div className="p-3.5 bg-slate-900 text-xs text-slate-300 border-t border-slate-800 leading-relaxed">
                  {faq.a}
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

    </div>
  );
};
