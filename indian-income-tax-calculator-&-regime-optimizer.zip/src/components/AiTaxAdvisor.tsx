import React, { useState } from 'react';
import { TaxInputs, TaxComputationResult } from '../types';
import Markdown from 'react-markdown';
import { Bot, Sparkles, Send, RefreshCw, AlertCircle, CheckCircle2 } from 'lucide-react';

interface AiTaxAdvisorProps {
  inputs: TaxInputs;
  oldRegime: TaxComputationResult;
  newRegime: TaxComputationResult;
}

export const AiTaxAdvisor: React.FC<AiTaxAdvisorProps> = ({ inputs, oldRegime, newRegime }) => {
  const [advice, setAdvice] = useState<string | null>(null);
  const [userQuestion, setUserQuestion] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const QUICK_QUESTIONS = [
    'How can I save ₹20,000 more tax under Old Regime?',
    'Is NPS Section 80CCD(1B) ₹50,000 investment beneficial for my salary level?',
    'Should I claim HRA if I pay rent to my parents?',
    'How does Section 80D senior citizen health insurance benefit my parents?',
  ];

  const fetchAiAdvice = async (question?: string) => {
    setIsLoading(true);
    setError(null);

    try {
      const response = await fetch('/api/ai-tax-advisor', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userProfile: inputs,
          oldRegimeResult: oldRegime,
          newRegimeResult: newRegime,
          userQuestion: question || userQuestion || undefined,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to get AI Tax advice.');
      }

      setAdvice(data.advice);
    } catch (err: any) {
      setError(err.message || 'Error communicating with AI Tax CA.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleQuickQuestion = (q: string) => {
    setUserQuestion(q);
    fetchAiAdvice(q);
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5 text-white">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <Bot className="w-5 h-5 text-emerald-400" />
          </div>
          <div>
            <div className="flex items-center space-x-2">
              <h3 className="text-lg font-bold text-white">AI Tax Optimization CA</h3>
              <span className="bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded-full font-mono font-semibold border border-emerald-500/30">
                Gemini AI
              </span>
            </div>
            <p className="text-xs text-slate-400">Personalized tax advisory based on your exact salary & deductions</p>
          </div>
        </div>

        <button
          onClick={() => fetchAiAdvice()}
          disabled={isLoading}
          className="flex items-center space-x-1.5 text-xs bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-medium px-3.5 py-2 rounded-xl transition-all shadow"
        >
          {isLoading ? (
            <RefreshCw className="w-3.5 h-3.5 animate-spin" />
          ) : (
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
          )}
          <span>{isLoading ? 'Analyzing...' : advice ? 'Re-Analyze Profile' : 'Generate AI Advice'}</span>
        </button>
      </div>

      {/* Quick Suggestion Chips */}
      <div className="space-y-2">
        <span className="text-xs text-slate-400 font-medium block">Ask AI Chartered Accountant:</span>
        <div className="flex flex-wrap gap-2">
          {QUICK_QUESTIONS.map((q, idx) => (
            <button
              key={idx}
              onClick={() => handleQuickQuestion(q)}
              disabled={isLoading}
              className="text-xs bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white px-3 py-1.5 rounded-xl border border-slate-700 transition-colors text-left"
            >
              "{q}"
            </button>
          ))}
        </div>
      </div>

      {/* Custom Question Input */}
      <div className="flex gap-2">
        <input
          type="text"
          value={userQuestion}
          onChange={(e) => setUserQuestion(e.target.value)}
          onKeyDown={(e) => e.key === 'Enter' && fetchAiAdvice()}
          placeholder="Ask any tax question e.g. 'Can I claim both HRA and Home Loan interest?'..."
          className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-emerald-500"
        />
        <button
          onClick={() => fetchAiAdvice()}
          disabled={isLoading}
          className="bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-xs font-semibold flex items-center space-x-1"
        >
          <Send className="w-3.5 h-3.5" />
          <span>Ask</span>
        </button>
      </div>

      {/* Error Message */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/30 p-3.5 rounded-xl text-xs text-rose-300 flex items-start space-x-2">
          <AlertCircle className="w-4 h-4 shrink-0 mt-0.5 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Advice Display Output */}
      {advice && (
        <div className="bg-slate-800/60 border border-slate-700/80 rounded-xl p-5 text-sm space-y-3">
          <div className="flex items-center space-x-2 text-emerald-400 text-xs font-bold border-b border-slate-700 pb-2">
            <CheckCircle2 className="w-4 h-4" />
            <span>AI CA Analysis & Savings Recommendations</span>
          </div>
          <div className="prose prose-invert prose-sm max-w-none text-slate-200 leading-relaxed space-y-2">
            <Markdown>{advice}</Markdown>
          </div>
        </div>
      )}

    </div>
  );
};
