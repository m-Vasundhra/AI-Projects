import React from 'react';
import { ComparisonResult } from '../types';
import { Target, Lightbulb, AlertTriangle, CheckCircle, ArrowRight } from 'lucide-react';

interface BreakevenAnalysisProps {
  comparison: ComparisonResult;
}

export const BreakevenAnalysis: React.FC<BreakevenAnalysisProps> = ({ comparison }) => {
  const { breakevenDeductions, currentDeductionsInOld, deductionShortfall, newRegime, oldRegime, recommendedRegime } =
    comparison;

  const formatRupee = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  const progressPct = breakevenDeductions > 0
    ? Math.min(100, Math.round((currentDeductionsInOld / breakevenDeductions) * 100))
    : 100;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-5 text-white">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-amber-500/10 text-amber-400">
            <Target className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Breakeven Deductions Analysis ("Magic Number")</h3>
            <p className="text-xs text-slate-400">
              Total deductions required under Old Regime to equal the New Regime tax liability
            </p>
          </div>
        </div>
      </div>

      {/* Main Metric Banner */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-slate-800/50 p-4 sm:p-5 rounded-xl border border-slate-700/80">
        
        {/* Breakeven Threshold */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400 font-medium">Breakeven Deduction Threshold</span>
          <div className="text-2xl font-extrabold text-amber-400 font-mono">
            {formatRupee(breakevenDeductions)}
          </div>
          <p className="text-[11px] text-slate-400">Total Old Regime exemptions needed to equal New Regime tax</p>
        </div>

        {/* Current Claimed */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400 font-medium">Current Claimed Deductions</span>
          <div className="text-2xl font-extrabold text-blue-400 font-mono">
            {formatRupee(currentDeductionsInOld)}
          </div>
          <p className="text-[11px] text-slate-400">Includes 80C, 80D, HRA, Standard Deduction & others</p>
        </div>

        {/* Deduction Shortfall or Surplus */}
        <div className="space-y-1">
          <span className="text-xs text-slate-400 font-medium">
            {deductionShortfall > 0 ? 'Deduction Shortfall' : 'Deduction Surplus'}
          </span>
          <div className={`text-2xl font-extrabold font-mono ${deductionShortfall > 0 ? 'text-rose-400' : 'text-emerald-400'}`}>
            {deductionShortfall > 0 ? formatRupee(deductionShortfall) : `Surplus ${formatRupee(Math.abs(deductionShortfall))}`}
          </div>
          <p className="text-[11px] text-slate-400">
            {deductionShortfall > 0
              ? 'Additional deductions needed to make Old Regime win'
              : 'Your current deductions successfully beat the breakeven threshold'}
          </p>
        </div>

      </div>

      {/* Progress Gauge Bar */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-300 font-medium">Progress towards Breakeven Threshold:</span>
          <span className="font-mono text-amber-400 font-bold">{progressPct}%</span>
        </div>
        <div className="w-full bg-slate-800 h-3 rounded-full overflow-hidden p-0.5 border border-slate-700">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              progressPct >= 100
                ? 'bg-gradient-to-r from-emerald-500 to-teal-400'
                : 'bg-gradient-to-r from-amber-500 to-orange-400'
            }`}
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Actionable Strategy Tip Box */}
      <div className="bg-slate-800/30 border border-slate-800 p-4 rounded-xl space-y-2 text-xs">
        <div className="flex items-center space-x-2 text-amber-400 font-semibold">
          <Lightbulb className="w-4 h-4" />
          <span>Strategic Takeaway for Your Profile:</span>
        </div>
        
        {deductionShortfall > 0 ? (
          <p className="text-slate-300 leading-relaxed">
            You are currently <strong className="text-amber-400 font-mono">{formatRupee(deductionShortfall)}</strong> short of the total deductions needed to make the Old Regime beneficial. Unless you have unclaimed HRA rent receipts, home loan interest, or Section 80D medical policies to add, <strong className="text-emerald-400">sticking with the New Tax Regime is mathematically optimal.</strong>
          </p>
        ) : (
          <p className="text-slate-300 leading-relaxed">
            Your current total deductions of <strong className="text-blue-400 font-mono">{formatRupee(currentDeductionsInOld)}</strong> exceed the required breakeven threshold of <strong className="text-amber-400 font-mono">{formatRupee(breakevenDeductions)}</strong>. <strong className="text-blue-400">Opting for the Old Tax Regime gives you higher net tax savings this year!</strong>
          </p>
        )}
      </div>

    </div>
  );
};
