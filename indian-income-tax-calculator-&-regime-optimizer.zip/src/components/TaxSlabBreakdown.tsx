import React from 'react';
import { TaxComputationResult } from '../types';
import { ListFilter, Layers } from 'lucide-react';

interface TaxSlabBreakdownProps {
  newRegime: TaxComputationResult;
  oldRegime: TaxComputationResult;
}

export const TaxSlabBreakdown: React.FC<TaxSlabBreakdownProps> = ({ newRegime, oldRegime }) => {
  const formatRupee = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6 text-white">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-teal-500/10 text-teal-400">
            <ListFilter className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Tax Bracket & Slab Calculation Details</h3>
            <p className="text-xs text-slate-400">Step-by-step slab computation applied to net taxable income</p>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        
        {/* New Regime Slabs */}
        <div className="space-y-3 bg-slate-800/40 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-emerald-400 flex items-center space-x-1.5">
              <Layers className="w-4 h-4" />
              <span>New Tax Regime Slabs (FY {newRegime.financialYear})</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              Taxable: {formatRupee(newRegime.taxableIncome)}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-800 text-slate-400 text-[11px] uppercase">
                <tr>
                  <th className="py-2 px-3">Income Range</th>
                  <th className="py-2 px-3 text-center">Rate</th>
                  <th className="py-2 px-3 text-right">Taxable Amount</th>
                  <th className="py-2 px-3 text-right">Tax</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {newRegime.slabBreakdown.map((slab, index) => (
                  <tr key={index} className="hover:bg-slate-800/50">
                    <td className="py-2 px-3 font-sans">{slab.range}</td>
                    <td className="py-2 px-3 text-center">{slab.rate}%</td>
                    <td className="py-2 px-3 text-right">{formatRupee(slab.taxableAmountInSlab)}</td>
                    <td className="py-2 px-3 text-right text-emerald-400 font-semibold">
                      {formatRupee(slab.taxForSlab)}
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-800/80 font-bold border-t border-slate-700">
                  <td colSpan={3} className="py-2.5 px-3 font-sans text-slate-200">Base Tax Before Rebate</td>
                  <td className="py-2.5 px-3 text-right text-emerald-400 font-mono text-sm">
                    {formatRupee(newRegime.baseTax)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {newRegime.sec87aRebate > 0 && (
            <div className="text-xs bg-emerald-500/10 border border-emerald-500/30 p-2.5 rounded-lg text-emerald-300 flex items-center justify-between font-mono">
              <span>Section 87A Rebate Applied:</span>
              <span>-{formatRupee(newRegime.sec87aRebate)}</span>
            </div>
          )}
        </div>

        {/* Old Regime Slabs */}
        <div className="space-y-3 bg-slate-800/40 border border-slate-800 p-4 rounded-xl">
          <div className="flex items-center justify-between">
            <h4 className="text-sm font-bold text-blue-400 flex items-center space-x-1.5">
              <Layers className="w-4 h-4" />
              <span>Old Tax Regime Slabs (FY {oldRegime.financialYear})</span>
            </h4>
            <span className="text-xs text-slate-400 font-mono">
              Taxable: {formatRupee(oldRegime.taxableIncome)}
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-800 text-slate-400 text-[11px] uppercase">
                <tr>
                  <th className="py-2 px-3">Income Range</th>
                  <th className="py-2 px-3 text-center">Rate</th>
                  <th className="py-2 px-3 text-right">Taxable Amount</th>
                  <th className="py-2 px-3 text-right">Tax</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800 text-slate-300">
                {oldRegime.slabBreakdown.map((slab, index) => (
                  <tr key={index} className="hover:bg-slate-800/50">
                    <td className="py-2 px-3 font-sans">{slab.range}</td>
                    <td className="py-2 px-3 text-center">{slab.rate}%</td>
                    <td className="py-2 px-3 text-right">{formatRupee(slab.taxableAmountInSlab)}</td>
                    <td className="py-2 px-3 text-right text-blue-400 font-semibold">
                      {formatRupee(slab.taxForSlab)}
                    </td>
                  </tr>
                ))}
                <tr className="bg-slate-800/80 font-bold border-t border-slate-700">
                  <td colSpan={3} className="py-2.5 px-3 font-sans text-slate-200">Base Tax Before Rebate</td>
                  <td className="py-2.5 px-3 text-right text-blue-400 font-mono text-sm">
                    {formatRupee(oldRegime.baseTax)}
                  </td>
                </tr>
              </tbody>
            </table>
          </div>

          {oldRegime.sec87aRebate > 0 && (
            <div className="text-xs bg-blue-500/10 border border-blue-500/30 p-2.5 rounded-lg text-blue-300 flex items-center justify-between font-mono">
              <span>Section 87A Rebate Applied:</span>
              <span>-{formatRupee(oldRegime.sec87aRebate)}</span>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
