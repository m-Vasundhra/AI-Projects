import React from 'react';
import { ComparisonResult } from '../types';
import { Trophy, CheckCircle2, TrendingUp, DollarSign, AlertCircle } from 'lucide-react';

interface WinnerBannerProps {
  comparison: ComparisonResult;
}

export const WinnerBanner: React.FC<WinnerBannerProps> = ({ comparison }) => {
  const { recommendedRegime, annualSavings, monthlySavings, oldRegime, newRegime } = comparison;

  const isNewOptimal = recommendedRegime === 'new';
  const isEqual = recommendedRegime === 'equal';

  const formatRupee = (amount: number) => `₹${amount.toLocaleString('en-IN')}`;

  return (
    <div
      className={`rounded-2xl p-5 sm:p-6 border shadow-lg transition-all ${
        isEqual
          ? 'bg-slate-900 border-slate-700 text-white'
          : isNewOptimal
          ? 'bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-900 border-emerald-500/40 text-white'
          : 'bg-gradient-to-r from-blue-950 via-slate-900 to-slate-900 border-blue-500/40 text-white'
      }`}
    >
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-6">
        
        {/* Left: Recommendation Statement */}
        <div className="space-y-2 max-w-2xl">
          <div className="flex items-center space-x-2">
            <span
              className={`inline-flex items-center space-x-1.5 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wide border ${
                isEqual
                  ? 'bg-slate-800 text-slate-300 border-slate-700'
                  : isNewOptimal
                  ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                  : 'bg-blue-500/20 text-blue-400 border-blue-500/30'
              }`}
            >
              <Trophy className="w-3.5 h-3.5" />
              <span>
                {isEqual
                  ? 'Equal Tax Outcome'
                  : isNewOptimal
                  ? 'New Tax Regime Recommended'
                  : 'Old Tax Regime Recommended'}
              </span>
            </span>
            <span className="text-xs text-slate-400 font-mono">
              FY {newRegime.financialYear}
            </span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            {isEqual ? (
              <span>Both regimes result in identical tax of {formatRupee(newRegime.totalTaxPayable)}</span>
            ) : isNewOptimal ? (
              <span>
                New Tax Regime saves you{' '}
                <span className="text-emerald-400 underline decoration-emerald-500/50 decoration-2">
                  {formatRupee(annualSavings)}
                </span>{' '}
                per year!
              </span>
            ) : (
              <span>
                Old Tax Regime saves you{' '}
                <span className="text-blue-400 underline decoration-blue-500/50 decoration-2">
                  {formatRupee(annualSavings)}
                </span>{' '}
                per year!
              </span>
            )}
          </h2>

          <p className="text-sm text-slate-300">
            {isEqual
              ? 'You have standard deductions that align your taxable brackets equally across both regimes.'
              : isNewOptimal
              ? `Under the New Regime (default), lower tax slab rates & ₹75k standard deduction beat your current total Old Regime deductions.`
              : `Your total Old Regime deductions (${formatRupee(
                  oldRegime.totalDeductionsAndExemptions
                )}) successfully outweigh the lower slab rates of the New Regime.`}
          </p>
        </div>

        {/* Right: Key Metric Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 shrink-0">
          
          {/* Annual Tax Comparison Card */}
          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center space-x-1">
              <DollarSign className="w-3.5 h-3.5 text-emerald-400" />
              <span>Annual Tax</span>
            </span>
            <div className="mt-2">
              <div className="text-xs text-slate-400 font-medium">New: <span className="text-white font-semibold font-mono">{formatRupee(newRegime.totalTaxPayable)}</span></div>
              <div className="text-xs text-slate-400 font-medium mt-0.5">Old: <span className="text-white font-semibold font-mono">{formatRupee(oldRegime.totalTaxPayable)}</span></div>
            </div>
          </div>

          {/* Monthly In-Hand Boost */}
          <div className="bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 flex flex-col justify-between">
            <span className="text-xs text-slate-400 flex items-center space-x-1">
              <TrendingUp className="w-3.5 h-3.5 text-amber-400" />
              <span>Monthly In-Hand</span>
            </span>
            <div className="mt-2">
              <div className="text-lg font-bold text-emerald-400 font-mono">
                +{formatRupee(monthlySavings)}<span className="text-xs font-normal text-slate-400">/mo</span>
              </div>
              <div className="text-[11px] text-slate-400">In-hand salary boost</div>
            </div>
          </div>

          {/* Effective Tax Rate */}
          <div className="col-span-2 sm:col-span-1 bg-slate-800/80 p-3.5 rounded-xl border border-slate-700/80 flex flex-col justify-between">
            <span className="text-xs text-slate-400">Effective Tax Rate</span>
            <div className="mt-2">
              <div className="text-base font-bold font-mono text-white">
                {isNewOptimal ? newRegime.effectiveTaxRate : oldRegime.effectiveTaxRate}%
              </div>
              <div className="text-[11px] text-slate-400">
                vs {isNewOptimal ? oldRegime.effectiveTaxRate : newRegime.effectiveTaxRate}% in other
              </div>
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
