import React from 'react';
import { ComparisonResult } from '../types';
import { X, Printer, Copy, Check, FileText } from 'lucide-react';

interface TaxReportModalProps {
  isOpen: boolean;
  onClose: () => void;
  comparison: ComparisonResult;
}

export const TaxReportModal: React.FC<TaxReportModalProps> = ({ isOpen, onClose, comparison }) => {
  const [copied, setCopied] = React.useState(false);

  if (!isOpen) return null;

  const { oldRegime, newRegime, recommendedRegime, annualSavings } = comparison;
  const formatRupee = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  const handlePrint = () => {
    window.print();
  };

  const handleCopy = () => {
    const textReport = `TAX COMPUTATION STATEMENT (FY ${newRegime.financialYear})
--------------------------------------------------
Gross Annual Income: ${formatRupee(newRegime.grossIncome)}

NEW TAX REGIME:
- Standard Deduction: ${formatRupee(newRegime.standardDeduction)}
- Net Taxable Income: ${formatRupee(newRegime.taxableIncome)}
- Base Tax: ${formatRupee(newRegime.baseTax)}
- Cess (4%): ${formatRupee(newRegime.cess)}
- TOTAL TAX PAYABLE: ${formatRupee(newRegime.totalTaxPayable)}
- Monthly Take-Home: ${formatRupee(newRegime.monthlyTakeHome)}

OLD TAX REGIME:
- Total Deductions & Exemptions: ${formatRupee(oldRegime.totalDeductionsAndExemptions)}
- Net Taxable Income: ${formatRupee(oldRegime.taxableIncome)}
- Base Tax: ${formatRupee(oldRegime.baseTax)}
- Cess (4%): ${formatRupee(oldRegime.cess)}
- TOTAL TAX PAYABLE: ${formatRupee(oldRegime.totalTaxPayable)}
- Monthly Take-Home: ${formatRupee(oldRegime.monthlyTakeHome)}

RECOMMENDATION: ${recommendedRegime.toUpperCase()} REGIME RECOMMENDED!
SAVINGS: ${formatRupee(annualSavings)} / year (${formatRupee(comparison.monthlySavings)} / month)
--------------------------------------------------
Generated via TaxRegime India Optimizer`;

    navigator.clipboard.writeText(textReport);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm animate-fade-in print:bg-white print:p-0">
      <div className="bg-slate-900 border border-slate-700 rounded-2xl w-full max-w-2xl shadow-2xl overflow-hidden text-white space-y-5 p-6 print:border-none print:shadow-none print:text-black print:bg-white print:w-full">
        
        {/* Top Header Controls */}
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 print:hidden">
          <div className="flex items-center space-x-2">
            <FileText className="w-5 h-5 text-emerald-400" />
            <h3 className="text-base font-bold text-white">Income Tax Computation Statement</h3>
          </div>
          <div className="flex items-center space-x-2">
            <button
              onClick={handleCopy}
              className="flex items-center space-x-1 text-xs bg-slate-800 hover:bg-slate-700 text-slate-200 px-3 py-1.5 rounded-lg border border-slate-700 transition-colors"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'Copy Summary'}</span>
            </button>
            <button
              onClick={handlePrint}
              className="flex items-center space-x-1 text-xs bg-emerald-600 hover:bg-emerald-500 text-white font-medium px-3 py-1.5 rounded-lg transition-colors"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>Print / Save PDF</span>
            </button>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Printable Statement Document */}
        <div className="space-y-4 text-xs font-mono border p-5 rounded-xl border-slate-800 bg-slate-950/60 print:border-slate-300 print:bg-white print:text-black">
          
          <div className="border-b border-slate-800 print:border-black pb-3 flex justify-between items-start font-sans">
            <div>
              <h2 className="text-lg font-bold">INCOME TAX ESTIMATION REPORT</h2>
              <p className="text-[11px] text-slate-400 print:text-gray-600">Financial Year: {newRegime.financialYear} | Assessment Year: 2025-26</p>
            </div>
            <div className="text-right">
              <span className="text-xs bg-emerald-500/20 text-emerald-400 px-2.5 py-1 rounded font-mono font-bold print:border print:border-black print:text-black">
                OPTIMAL: {recommendedRegime.toUpperCase()} REGIME
              </span>
            </div>
          </div>

          <table className="w-full text-left font-mono text-xs">
            <thead className="border-b border-slate-800 text-slate-400 print:border-black print:text-black font-semibold">
              <tr>
                <th className="py-1.5">Particulars</th>
                <th className="py-1.5 text-right">New Regime</th>
                <th className="py-1.5 text-right">Old Regime</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 print:divide-gray-300">
              <tr>
                <td className="py-1.5">Gross Total Income</td>
                <td className="py-1.5 text-right">{formatRupee(newRegime.grossIncome)}</td>
                <td className="py-1.5 text-right">{formatRupee(oldRegime.grossIncome)}</td>
              </tr>
              <tr>
                <td className="py-1.5">Total Deductions & Exemptions</td>
                <td className="py-1.5 text-right">{formatRupee(newRegime.totalDeductionsAndExemptions)}</td>
                <td className="py-1.5 text-right">{formatRupee(oldRegime.totalDeductionsAndExemptions)}</td>
              </tr>
              <tr className="font-bold">
                <td className="py-1.5">Net Taxable Income</td>
                <td className="py-1.5 text-right">{formatRupee(newRegime.taxableIncome)}</td>
                <td className="py-1.5 text-right">{formatRupee(oldRegime.taxableIncome)}</td>
              </tr>
              <tr>
                <td className="py-1.5">Base Tax on Slabs</td>
                <td className="py-1.5 text-right">{formatRupee(newRegime.baseTax)}</td>
                <td className="py-1.5 text-right">{formatRupee(oldRegime.baseTax)}</td>
              </tr>
              <tr>
                <td className="py-1.5">Sec 87A Tax Rebate</td>
                <td className="py-1.5 text-right">-{formatRupee(newRegime.sec87aRebate)}</td>
                <td className="py-1.5 text-right">-{formatRupee(oldRegime.sec87aRebate)}</td>
              </tr>
              <tr>
                <td className="py-1.5">Health & Education Cess (4%)</td>
                <td className="py-1.5 text-right">{formatRupee(newRegime.cess)}</td>
                <td className="py-1.5 text-right">{formatRupee(oldRegime.cess)}</td>
              </tr>
              <tr className="font-extrabold text-sm border-t-2 border-slate-700 print:border-black">
                <td className="py-2">NET TAX PAYABLE</td>
                <td className="py-2 text-right text-emerald-400 print:text-black">{formatRupee(newRegime.totalTaxPayable)}</td>
                <td className="py-2 text-right text-blue-400 print:text-black">{formatRupee(oldRegime.totalTaxPayable)}</td>
              </tr>
            </tbody>
          </table>

          <div className="bg-slate-900 print:bg-gray-100 p-3 rounded-lg border border-slate-800 print:border-gray-300 font-sans text-xs space-y-1">
            <div className="font-bold text-emerald-400 print:text-black">
              Recommendation Summary:
            </div>
            <div>
              By adopting the <strong className="uppercase">{recommendedRegime} Tax Regime</strong>, your annual tax liability is reduced by <strong className="text-emerald-400 print:text-black font-mono">{formatRupee(annualSavings)}</strong>, boosting your monthly take-home salary by <strong className="text-emerald-400 print:text-black font-mono">{formatRupee(comparison.monthlySavings)}</strong>.
            </div>
          </div>

        </div>

      </div>
    </div>
  );
};
