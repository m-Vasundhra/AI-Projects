import React from 'react';
import { ComparisonResult } from '../types';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  Cell,
} from 'recharts';
import { Scale, CheckCircle, ArrowUpRight, ArrowDownRight, Zap } from 'lucide-react';

interface ComparisonSummaryProps {
  comparison: ComparisonResult;
}

export const ComparisonSummary: React.FC<ComparisonSummaryProps> = ({ comparison }) => {
  const { oldRegime, newRegime, recommendedRegime, annualSavings } = comparison;

  const formatRupee = (val: number) => `₹${val.toLocaleString('en-IN')}`;

  // Chart data
  const chartData = [
    {
      metric: 'Total Tax Payable',
      'New Regime': newRegime.totalTaxPayable,
      'Old Regime': oldRegime.totalTaxPayable,
    },
    {
      metric: 'Monthly Take-Home',
      'New Regime': newRegime.monthlyTakeHome,
      'Old Regime': oldRegime.monthlyTakeHome,
    },
  ];

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6 text-white">
      
      {/* Header */}
      <div className="flex items-center justify-between border-b border-slate-800 pb-4">
        <div className="flex items-center space-x-2.5">
          <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
            <Scale className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold text-white">Regime Comparative Analysis</h3>
            <p className="text-xs text-slate-400">Detailed line-by-line financial breakdown for FY {newRegime.financialYear}</p>
          </div>
        </div>
      </div>

      {/* Visual Recharts Bar Chart */}
      <div className="bg-slate-800/40 border border-slate-800 rounded-xl p-4 space-y-2">
        <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center space-x-1.5">
          <Zap className="w-3.5 h-3.5 text-amber-400" />
          <span>Visual Comparison: Tax Payable & Monthly Take-Home</span>
        </h4>
        
        <div className="h-64 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <BarChart
              data={chartData}
              margin={{ top: 20, right: 20, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
              <XAxis dataKey="metric" stroke="#94a3b8" tick={{ fontSize: 12 }} />
              <YAxis
                stroke="#94a3b8"
                tickFormatter={(val) => `₹${(val / 1000).toFixed(0)}k`}
                tick={{ fontSize: 11 }}
              />
              <Tooltip
                formatter={(value: any) => [`₹${Number(value).toLocaleString('en-IN')}`, '']}
                contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px', color: '#fff' }}
              />
              <Legend wrapperStyle={{ paddingTop: '10px', fontSize: '12px' }} />
              <Bar dataKey="New Regime" fill="#10b981" radius={[6, 6, 0, 0]} barSize={40} />
              <Bar dataKey="Old Regime" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={40} />
            </BarChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Side-by-Side Detailed Breakdown Table */}
      <div className="overflow-x-auto rounded-xl border border-slate-800">
        <table className="w-full text-left text-xs">
          <thead className="bg-slate-800/90 text-slate-300 font-semibold uppercase tracking-wider border-b border-slate-700">
            <tr>
              <th className="py-3 px-4">Financial Component</th>
              <th className="py-3 px-4 text-right text-emerald-400">
                New Tax Regime
                {recommendedRegime === 'new' && (
                  <span className="ml-1.5 bg-emerald-500/20 text-emerald-400 text-[10px] px-2 py-0.5 rounded font-mono">
                    WINNER
                  </span>
                )}
              </th>
              <th className="py-3 px-4 text-right text-blue-400">
                Old Tax Regime
                {recommendedRegime === 'old' && (
                  <span className="ml-1.5 bg-blue-500/20 text-blue-400 text-[10px] px-2 py-0.5 rounded font-mono">
                    WINNER
                  </span>
                )}
              </th>
              <th className="py-3 px-4 text-right text-slate-400">Difference</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/80 font-mono text-slate-200">
            
            {/* Gross Total Income */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans font-medium text-slate-300">Gross Annual Income</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(newRegime.grossIncome)}</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(oldRegime.grossIncome)}</td>
              <td className="py-2.5 px-4 text-right text-slate-500">₹0</td>
            </tr>

            {/* Standard Deduction */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400 pl-6">(-) Standard Deduction</td>
              <td className="py-2.5 px-4 text-right text-emerald-400">{formatRupee(newRegime.standardDeduction)}</td>
              <td className="py-2.5 px-4 text-right text-blue-400">{formatRupee(oldRegime.standardDeduction)}</td>
              <td className="py-2.5 px-4 text-right text-emerald-400">
                +{formatRupee(newRegime.standardDeduction - oldRegime.standardDeduction)}
              </td>
            </tr>

            {/* HRA Exemption */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400 pl-6">(-) HRA Exemption Sec 10(13A)</td>
              <td className="py-2.5 px-4 text-right text-slate-500">N/A (₹0)</td>
              <td className="py-2.5 px-4 text-right text-blue-400">{formatRupee(oldRegime.hraExemption)}</td>
              <td className="py-2.5 px-4 text-right text-blue-400">-{formatRupee(oldRegime.hraExemption)}</td>
            </tr>

            {/* 80C & Other Deductions */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400 pl-6">(-) Chapter VI-A Deductions (80C, 80D, NPS, Sec 24)</td>
              <td className="py-2.5 px-4 text-right text-emerald-400">
                {formatRupee(newRegime.npsEmployerDeduction)} <span className="text-[10px] text-slate-500 font-sans">(80CCD2 only)</span>
              </td>
              <td className="py-2.5 px-4 text-right text-blue-400">
                {formatRupee(oldRegime.totalDeductionsAndExemptions - oldRegime.standardDeduction - oldRegime.hraExemption)}
              </td>
              <td className="py-2.5 px-4 text-right text-blue-400">
                -{formatRupee(
                  oldRegime.totalDeductionsAndExemptions -
                  oldRegime.standardDeduction -
                  oldRegime.hraExemption -
                  newRegime.npsEmployerDeduction
                )}
              </td>
            </tr>

            {/* Total Deductions Header Row */}
            <tr className="bg-slate-800/50 font-bold font-sans text-slate-200">
              <td className="py-3 px-4">Total Deductions & Exemptions</td>
              <td className="py-3 px-4 text-right font-mono text-emerald-400">{formatRupee(newRegime.totalDeductionsAndExemptions)}</td>
              <td className="py-3 px-4 text-right font-mono text-blue-400">{formatRupee(oldRegime.totalDeductionsAndExemptions)}</td>
              <td className="py-3 px-4 text-right font-mono text-blue-400">
                +{formatRupee(oldRegime.totalDeductionsAndExemptions - newRegime.totalDeductionsAndExemptions)}
              </td>
            </tr>

            {/* Net Taxable Income */}
            <tr className="hover:bg-slate-800/30 font-semibold">
              <td className="py-3 px-4 font-sans text-slate-200">Net Taxable Income</td>
              <td className="py-3 px-4 text-right">{formatRupee(newRegime.taxableIncome)}</td>
              <td className="py-3 px-4 text-right">{formatRupee(oldRegime.taxableIncome)}</td>
              <td className="py-3 px-4 text-right text-slate-400">
                {formatRupee(Math.abs(newRegime.taxableIncome - oldRegime.taxableIncome))}
              </td>
            </tr>

            {/* Base Slab Tax */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400">Income Tax (Calculated on Slabs)</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(newRegime.baseTax)}</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(oldRegime.baseTax)}</td>
              <td className="py-2.5 px-4 text-right text-slate-400">
                {formatRupee(Math.abs(newRegime.baseTax - oldRegime.baseTax))}
              </td>
            </tr>

            {/* Rebate Sec 87A */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400">(-) Section 87A Tax Rebate</td>
              <td className="py-2.5 px-4 text-right text-emerald-400">-{formatRupee(newRegime.sec87aRebate)}</td>
              <td className="py-2.5 px-4 text-right text-blue-400">-{formatRupee(oldRegime.sec87aRebate)}</td>
              <td className="py-2.5 px-4 text-right text-slate-400">-</td>
            </tr>

            {/* Cess (4%) */}
            <tr className="hover:bg-slate-800/30">
              <td className="py-2.5 px-4 font-sans text-slate-400">(+) Health & Education Cess (4%)</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(newRegime.cess)}</td>
              <td className="py-2.5 px-4 text-right">{formatRupee(oldRegime.cess)}</td>
              <td className="py-2.5 px-4 text-right text-slate-400">
                {formatRupee(Math.abs(newRegime.cess - oldRegime.cess))}
              </td>
            </tr>

            {/* Final Total Tax Payable */}
            <tr className="bg-slate-800 font-extrabold text-sm border-t-2 border-slate-700">
              <td className="py-3.5 px-4 font-sans text-white">TOTAL TAX PAYABLE</td>
              <td className={`py-3.5 px-4 text-right ${recommendedRegime === 'new' ? 'text-emerald-400 font-mono text-base' : 'text-slate-200'}`}>
                {formatRupee(newRegime.totalTaxPayable)}
              </td>
              <td className={`py-3.5 px-4 text-right ${recommendedRegime === 'old' ? 'text-blue-400 font-mono text-base' : 'text-slate-200'}`}>
                {formatRupee(oldRegime.totalTaxPayable)}
              </td>
              <td className="py-3.5 px-4 text-right text-emerald-400 font-mono text-base">
                {annualSavings > 0 ? `${formatRupee(annualSavings)} Saved` : 'Equal'}
              </td>
            </tr>

            {/* Monthly Take-Home */}
            <tr className="bg-slate-900/90 font-bold font-sans">
              <td className="py-3 px-4 text-slate-300">Monthly Take-Home Pay</td>
              <td className="py-3 px-4 text-right text-emerald-400 font-mono">{formatRupee(newRegime.monthlyTakeHome)}/mo</td>
              <td className="py-3 px-4 text-right text-blue-400 font-mono">{formatRupee(oldRegime.monthlyTakeHome)}/mo</td>
              <td className="py-3 px-4 text-right text-emerald-400 font-mono">
                {comparison.monthlySavings > 0 ? `+${formatRupee(comparison.monthlySavings)}/mo` : 'Equal'}
              </td>
            </tr>

          </tbody>
        </table>
      </div>

    </div>
  );
};
