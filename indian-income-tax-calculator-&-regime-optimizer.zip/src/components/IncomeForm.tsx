import React from 'react';
import { TaxInputs, AgeGroup, EmploymentType } from '../types';
import { User, DollarSign, Home, Building, Calculator, Info } from 'lucide-react';

interface IncomeFormProps {
  inputs: TaxInputs;
  onChange: (key: keyof TaxInputs, value: any) => void;
  onOpenHraCalc: () => void;
}

export const IncomeForm: React.FC<IncomeFormProps> = ({ inputs, onChange, onOpenHraCalc }) => {

  const handleGrossSalaryChange = (val: number) => {
    onChange('grossSalary', val);
    // Suggest basic salary as 50% of gross if basic is currently 0 or proportional
    if (val > 0 && (inputs.basicSalary === 0 || inputs.basicSalary === Math.round(inputs.grossSalary * 0.5))) {
      onChange('basicSalary', Math.round(val * 0.5));
    }
  };

  return (
    <div className="bg-slate-900 border border-slate-800 rounded-2xl p-5 sm:p-6 space-y-6 text-white">
      
      {/* Section Header */}
      <div className="flex items-center space-x-2.5 border-b border-slate-800 pb-4">
        <div className="p-2 rounded-lg bg-emerald-500/10 text-emerald-400">
          <User className="w-5 h-5" />
        </div>
        <div>
          <h3 className="text-lg font-bold text-white">Tax Profile & Salary Income</h3>
          <p className="text-xs text-slate-400">Provide basic demographic and salary details for accurate tax computation</p>
        </div>
      </div>

      {/* Profile Selectors: Age & Employment */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        
        {/* Age Group */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Age Category</span>
            <span className="text-[11px] text-slate-400 font-normal">Sets basic exemption limit</span>
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700">
            {[
              { id: 'below60', label: '< 60 yrs', desc: 'Standard' },
              { id: 'senior60', label: '60 - 79 yrs', desc: 'Senior' },
              { id: 'superSenior80', label: '80+ yrs', desc: 'Super Sr.' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onChange('ageGroup', item.id as AgeGroup)}
                className={`py-2 px-1 rounded-lg text-xs font-medium text-center transition-all ${
                  inputs.ageGroup === item.id
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <div>{item.label}</div>
              </button>
            ))}
          </div>
        </div>

        {/* Employment Type */}
        <div className="space-y-1.5">
          <label className="text-xs font-semibold text-slate-300 flex items-center justify-between">
            <span>Employment Type</span>
            <span className="text-[11px] text-slate-400 font-normal">Controls standard deduction</span>
          </label>
          <div className="grid grid-cols-3 gap-1.5 p-1 bg-slate-800/80 rounded-xl border border-slate-700">
            {[
              { id: 'salaried', label: 'Salaried' },
              { id: 'pensioner', label: 'Pensioner' },
              { id: 'selfEmployed', label: 'Business/Self' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => onChange('employmentType', item.id as EmploymentType)}
                className={`py-2 px-1 rounded-lg text-xs font-medium text-center transition-all ${
                  inputs.employmentType === item.id
                    ? 'bg-emerald-500 text-slate-950 font-bold shadow'
                    : 'text-slate-300 hover:text-white hover:bg-slate-700/50'
                }`}
              >
                <div>{item.label}</div>
              </button>
            ))}
          </div>
        </div>

      </div>

      {/* Income Fields */}
      <div className="space-y-4 pt-2 border-t border-slate-800/80">
        <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Salary Breakdown (Annual)</h4>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Gross Annual Salary */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
              <span>Gross Salary Income (p.a.)</span>
              <span className="text-emerald-400 text-[11px] font-mono">CTC / Form 16</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">₹</span>
              <input
                type="number"
                min="0"
                step="10000"
                value={inputs.grossSalary || ''}
                onChange={(e) => handleGrossSalaryChange(Number(e.target.value))}
                placeholder="e.g. 1200000"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono font-medium"
              />
            </div>
          </div>

          {/* Basic Salary */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
              <span>Basic Salary + DA</span>
              <button
                type="button"
                onClick={() => onChange('basicSalary', Math.round(inputs.grossSalary * 0.5))}
                className="text-[10px] text-emerald-400 hover:underline"
              >
                Set 50% of Gross
              </button>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">₹</span>
              <input
                type="number"
                min="0"
                step="5000"
                value={inputs.basicSalary || ''}
                onChange={(e) => onChange('basicSalary', Number(e.target.value))}
                placeholder="e.g. 600000"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono font-medium"
              />
            </div>
          </div>

        </div>

        {/* HRA & Rent Details */}
        <div className="p-4 rounded-xl bg-slate-800/50 border border-slate-700/60 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <Home className="w-4 h-4 text-emerald-400" />
              <span className="text-xs font-semibold text-slate-200">House Rent Allowance (HRA) Details</span>
            </div>
            <button
              type="button"
              onClick={onOpenHraCalc}
              className="text-[11px] text-amber-400 hover:text-amber-300 flex items-center space-x-1 underline"
            >
              <Calculator className="w-3 h-3" />
              <span>Full HRA Calculator</span>
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            
            {/* HRA Received */}
            <div className="space-y-1">
              <label className="text-[11px] text-slate-400">HRA Allowance Received</label>
              <div className="relative">
                <span className="absolute left-2.5 top-2 text-slate-400 text-xs">₹</span>
                <input
                  type="number"
                  min="0"
                  value={inputs.hraReceived || ''}
                  onChange={(e) => onChange('hraReceived', Number(e.target.value))}
                  placeholder="e.g. 240000"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* Rent Paid */}
            <div className="space-y-1">
              <label className="text-[11px] text-slate-400">Annual Rent Paid</label>
              <div className="relative">
                <span className="absolute left-2.5 top-2 text-slate-400 text-xs">₹</span>
                <input
                  type="number"
                  min="0"
                  value={inputs.rentPaid || ''}
                  onChange={(e) => onChange('rentPaid', Number(e.target.value))}
                  placeholder="e.g. 216000"
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-6 pr-2 py-1.5 text-xs text-white font-mono"
                />
              </div>
            </div>

            {/* Metro Toggle */}
            <div className="space-y-1">
              <label className="text-[11px] text-slate-400">City Type</label>
              <div className="grid grid-cols-2 gap-1 p-0.5 bg-slate-800 rounded-lg border border-slate-700">
                <button
                  type="button"
                  onClick={() => onChange('isMetro', true)}
                  className={`py-1 text-[11px] font-medium rounded ${
                    inputs.isMetro ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'
                  }`}
                >
                  Metro (50%)
                </button>
                <button
                  type="button"
                  onClick={() => onChange('isMetro', false)}
                  className={`py-1 text-[11px] font-medium rounded ${
                    !inputs.isMetro ? 'bg-emerald-500 text-slate-950 font-bold' : 'text-slate-400'
                  }`}
                >
                  Non-Metro (40%)
                </button>
              </div>
            </div>

          </div>
          <p className="text-[10px] text-slate-400">
            * Metro cities: Delhi, Mumbai, Kolkata, Chennai. HRA exemption is allowed strictly under Old Tax Regime.
          </p>
        </div>

        {/* Other Income Sources & Home Loan */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          
          {/* Income from Other Sources */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
              <span>Other Income (Interest/FD/Dividends)</span>
              <span className="text-[10px] text-slate-400">Savings & FD interest</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">₹</span>
              <input
                type="number"
                min="0"
                value={inputs.otherIncome || ''}
                onChange={(e) => onChange('otherIncome', Number(e.target.value))}
                placeholder="e.g. 25000"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

          {/* Home Loan Interest Sec 24b */}
          <div className="space-y-1">
            <label className="text-xs font-medium text-slate-300 flex items-center justify-between">
              <span>Home Loan Interest (Sec 24b)</span>
              <span className="text-[10px] text-slate-400">Max ₹2 Lakhs (Self Occupied)</span>
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">₹</span>
              <input
                type="number"
                min="0"
                max="200000"
                value={inputs.homeLoanInterest || ''}
                onChange={(e) => onChange('homeLoanInterest', Number(e.target.value))}
                placeholder="e.g. 200000"
                className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-7 pr-3 py-2 text-sm text-white focus:outline-none focus:border-emerald-500 font-mono"
              />
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
