export type FinancialYear = '2024-25' | '2025-26' | '2023-24';

export type AgeGroup = 'below60' | 'senior60' | 'superSenior80';

export type EmploymentType = 'salaried' | 'selfEmployed' | 'pensioner';

export interface TaxInputs {
  financialYear: FinancialYear;
  ageGroup: AgeGroup;
  employmentType: EmploymentType;

  // Income details
  grossSalary: number;
  basicSalary: number;
  hraReceived: number;
  rentPaid: number;
  isMetro: boolean;
  specialAllowance: number;
  otherSalaryAllowances: number;
  ltaReceived: number;
  
  // Other Incomes
  homeLoanInterest: number; // Sec 24(b) - negative if self occupied loss
  otherIncome: number; // Savings interest, FD interest, Dividends, etc.
  
  // Deductions for Old Regime
  sec80C: number; // EPF, PPF, ELSS, Insurance, Home Loan Principal, etc. (Max 1.5L)
  sec80D_self: number; // Health Insurance Self & Family (Max 25k/50k)
  sec80D_parents: number; // Health Insurance Parents (Max 25k/50k)
  sec80CCD1B: number; // Employee NPS (Max 50k)
  sec80CCD2: number; // Employer NPS (Allowed in both regimes up to 14%/10% basic)
  sec80TTA: number; // Savings interest deduction (Max 10k/50k)
  sec80E: number; // Education Loan Interest
  sec80G: number; // Charitable Donations
  professionalTax: number; // Max 2.5k
  otherDeductions: number; // 80DD, 80U, 80EEA, etc.
}

export interface SlabBreakdown {
  range: string;
  rate: number;
  taxableAmountInSlab: number;
  taxForSlab: number;
}

export interface TaxComputationResult {
  regime: 'old' | 'new';
  financialYear: FinancialYear;
  grossIncome: number;
  
  // Deductions breakdown
  standardDeduction: number;
  hraExemption: number;
  total80CDeduction: number;
  total80DDeduction: number;
  npsEmployeeDeduction: number;
  npsEmployerDeduction: number;
  homeLoanDeduction: number;
  otherDeductionsSum: number;
  totalDeductionsAndExemptions: number;

  // Tax calculations
  grossTaxableIncome: number;
  taxableIncome: number;
  slabBreakdown: SlabBreakdown[];
  baseTax: number;
  
  // Rebates & Surcharges
  sec87aRebate: number;
  marginalRelief87A: number;
  taxAfterRebate: number;
  
  surchargeRate: number;
  surchargeAmount: number;
  surchargeMarginalRelief: number;
  
  cess: number; // 4%
  
  totalTaxPayable: number;
  effectiveTaxRate: number; // percentage
  monthlyTakeHome: number;
  monthlyTax: number;
}

export interface ComparisonResult {
  oldRegime: TaxComputationResult;
  newRegime: TaxComputationResult;
  recommendedRegime: 'old' | 'new' | 'equal';
  taxDifference: number; // positive number
  annualSavings: number;
  monthlySavings: number;
  breakevenDeductions: number; // Total deductions required in Old Regime to match New Regime tax
  currentDeductionsInOld: number;
  deductionShortfall: number; // breakeven - current
}
