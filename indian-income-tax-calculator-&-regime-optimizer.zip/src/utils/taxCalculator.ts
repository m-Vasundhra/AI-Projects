import { TaxInputs, TaxComputationResult, ComparisonResult, SlabBreakdown } from '../types';

/**
 * Calculates HRA Exemption under Section 10(13A)
 */
export function calculateHraExemption(
  basicSalary: number,
  hraReceived: number,
  rentPaid: number,
  isMetro: boolean
): number {
  if (hraReceived <= 0 || rentPaid <= 0 || basicSalary <= 0) {
    return 0;
  }
  const rentOver10Percent = Math.max(0, rentPaid - 0.10 * basicSalary);
  const cityPercentage = isMetro ? 0.50 : 0.40;
  const metroLimit = cityPercentage * basicSalary;

  return Math.max(0, Math.min(hraReceived, rentOver10Percent, metroLimit));
}

/**
 * Compute Tax under New Tax Regime
 */
export function computeNewRegimeTax(inputs: TaxInputs): TaxComputationResult {
  const isSalaried = inputs.employmentType === 'salaried' || inputs.employmentType === 'pensioner';
  
  // Standard Deduction in New Regime (FY 2024-25 & FY 2025-26 = ₹75,000; FY 2023-24 = ₹50,000)
  let standardDeduction = 0;
  if (isSalaried) {
    standardDeduction = inputs.financialYear === '2023-24' ? 50000 : 75000;
  }

  // Employer NPS 80CCD(2) allowed in New Regime (up to 14% of basic or actual entered)
  const maxNpsEmployer = 0.14 * inputs.basicSalary;
  const npsEmployerDeduction = Math.min(inputs.sec80CCD2 || 0, maxNpsEmployer > 0 ? maxNpsEmployer : inputs.sec80CCD2 || 0);

  const totalDeductionsAndExemptions = standardDeduction + npsEmployerDeduction;

  const totalGrossIncome = inputs.grossSalary + inputs.otherIncome;
  const taxableIncome = Math.max(0, totalGrossIncome - totalDeductionsAndExemptions);

  // Slabs calculation
  const slabBreakdown: SlabBreakdown[] = [];
  let baseTax = 0;

  if (inputs.financialYear === '2023-24') {
    // Slabs for FY 23-24
    const slabs = [
      { range: 'Up to ₹3,00,000', limit: 300000, rate: 0 },
      { range: '₹3,00,001 - ₹6,00,000', limit: 600000, rate: 0.05 },
      { range: '₹6,00,001 - ₹9,00,000', limit: 900000, rate: 0.10 },
      { range: '₹9,00,001 - ₹12,00,000', limit: 1200000, rate: 0.15 },
      { range: '₹12,00,001 - ₹15,00,000', limit: 1500000, rate: 0.20 },
      { range: 'Above ₹15,00,000', limit: Infinity, rate: 0.30 },
    ];
    let prev = 0;
    for (const slab of slabs) {
      if (taxableIncome > prev) {
        const slabTaxable = Math.min(taxableIncome, slab.limit) - prev;
        const taxForSlab = slabTaxable * slab.rate;
        baseTax += taxForSlab;
        slabBreakdown.push({
          range: slab.range,
          rate: slab.rate * 100,
          taxableAmountInSlab: slabTaxable,
          taxForSlab: Math.round(taxForSlab),
        });
        prev = slab.limit;
      }
    }
  } else {
    // Slabs for FY 2024-25 & FY 2025-26 (Budget 2024 updates)
    const slabs = [
      { range: 'Up to ₹3,00,000', limit: 300000, rate: 0 },
      { range: '₹3,00,001 - ₹7,00,000', limit: 700000, rate: 0.05 },
      { range: '₹7,00,001 - ₹10,00,000', limit: 1000000, rate: 0.10 },
      { range: '₹10,00,001 - ₹12,00,000', limit: 1200000, rate: 0.15 },
      { range: '₹12,00,001 - ₹15,00,000', limit: 1500000, rate: 0.20 },
      { range: 'Above ₹15,00,000', limit: Infinity, rate: 0.30 },
    ];
    let prev = 0;
    for (const slab of slabs) {
      if (taxableIncome > prev) {
        const slabTaxable = Math.min(taxableIncome, slab.limit) - prev;
        const taxForSlab = slabTaxable * slab.rate;
        baseTax += taxForSlab;
        slabBreakdown.push({
          range: slab.range,
          rate: slab.rate * 100,
          taxableAmountInSlab: slabTaxable,
          taxForSlab: Math.round(taxForSlab),
        });
        prev = slab.limit;
      }
    }
  }

  // Section 87A Rebate & Marginal Relief
  let sec87aRebate = 0;
  let marginalRelief87A = 0;
  let taxAfterRebate = baseTax;

  if (taxableIncome <= 700000) {
    sec87aRebate = baseTax;
    taxAfterRebate = 0;
  } else {
    // Marginal relief under 87A for New Regime (If taxable income slightly > 7L, tax should not exceed income over 7L)
    const excessIncomeOver7L = taxableIncome - 700000;
    if (baseTax > excessIncomeOver7L) {
      marginalRelief87A = baseTax - excessIncomeOver7L;
      taxAfterRebate = excessIncomeOver7L;
    }
  }

  // Surcharge
  const surchargeInfo = calculateSurcharge(taxableIncome, taxAfterRebate, 'new');
  const surchargeAmount = surchargeInfo.surchargeAmount;
  const surchargeRate = surchargeInfo.surchargeRate;

  const totalBeforeCess = taxAfterRebate + surchargeAmount;
  const cess = Math.round(totalBeforeCess * 0.04);
  const totalTaxPayable = Math.round(totalBeforeCess + cess);

  const effectiveTaxRate = totalGrossIncome > 0 ? (totalTaxPayable / totalGrossIncome) * 100 : 0;
  const netInHandAnnual = Math.max(0, totalGrossIncome - totalTaxPayable);

  return {
    regime: 'new',
    financialYear: inputs.financialYear,
    grossIncome: totalGrossIncome,
    standardDeduction,
    hraExemption: 0,
    total80CDeduction: 0,
    total80DDeduction: 0,
    npsEmployeeDeduction: 0,
    npsEmployerDeduction,
    homeLoanDeduction: 0,
    otherDeductionsSum: 0,
    totalDeductionsAndExemptions,
    grossTaxableIncome: totalGrossIncome,
    taxableIncome,
    slabBreakdown,
    baseTax: Math.round(baseTax),
    sec87aRebate: Math.round(sec87aRebate),
    marginalRelief87A: Math.round(marginalRelief87A),
    taxAfterRebate: Math.round(taxAfterRebate),
    surchargeRate,
    surchargeAmount: Math.round(surchargeAmount),
    surchargeMarginalRelief: Math.round(surchargeInfo.marginalRelief),
    cess,
    totalTaxPayable,
    effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
    monthlyTakeHome: Math.round(netInHandAnnual / 12),
    monthlyTax: Math.round(totalTaxPayable / 12),
  };
}

/**
 * Compute Tax under Old Tax Regime
 */
export function computeOldRegimeTax(inputs: TaxInputs): TaxComputationResult {
  const isSalaried = inputs.employmentType === 'salaried' || inputs.employmentType === 'pensioner';

  // 1. Standard Deduction
  const standardDeduction = isSalaried ? 50000 : 0;

  // 2. HRA Exemption
  const hraExemption = calculateHraExemption(
    inputs.basicSalary,
    inputs.hraReceived,
    inputs.rentPaid,
    inputs.isMetro
  );

  // 3. 80C (Max 1,50,000)
  const total80CDeduction = Math.min(150000, Math.max(0, inputs.sec80C || 0));

  // 4. 80D (Self + Parents)
  const isSeniorSelf = inputs.ageGroup === 'senior60' || inputs.ageGroup === 'superSenior80';
  const selfLimit = isSeniorSelf ? 50000 : 25000;
  const parentLimit = 50000; // conservative parent cap (or 25k/50k)
  const sec80D_self_capped = Math.min(selfLimit, Math.max(0, inputs.sec80D_self || 0));
  const sec80D_parents_capped = Math.min(parentLimit, Math.max(0, inputs.sec80D_parents || 0));
  const total80DDeduction = sec80D_self_capped + sec80D_parents_capped;

  // 5. Employee NPS 80CCD(1B) (Max 50,000)
  const npsEmployeeDeduction = Math.min(50000, Math.max(0, inputs.sec80CCD1B || 0));

  // 6. Employer NPS 80CCD(2) (Up to 10% basic)
  const maxNpsEmployer = 0.10 * inputs.basicSalary;
  const npsEmployerDeduction = Math.min(inputs.sec80CCD2 || 0, maxNpsEmployer > 0 ? maxNpsEmployer : inputs.sec80CCD2 || 0);

  // 7. Home Loan Interest Sec 24(b) (Max 2,00,000 for self occupied)
  const homeLoanDeduction = Math.min(200000, Math.max(0, inputs.homeLoanInterest || 0));

  // 8. 80TTA / 80TTB
  const maxTTA = isSeniorSelf ? 50000 : 10000;
  const ttaDeduction = Math.min(maxTTA, Math.max(0, inputs.sec80TTA || 0));

  // 9. Other deductions
  const profTax = Math.min(2500, Math.max(0, inputs.professionalTax || 0));
  const ltaExempt = Math.max(0, inputs.ltaReceived || 0);
  const otherDeductionsSum =
    Math.max(0, inputs.sec80E || 0) +
    Math.max(0, inputs.sec80G || 0) +
    Math.max(0, inputs.otherDeductions || 0) +
    profTax +
    ltaExempt +
    ttaDeduction;

  const totalDeductionsAndExemptions =
    standardDeduction +
    hraExemption +
    total80CDeduction +
    total80DDeduction +
    npsEmployeeDeduction +
    npsEmployerDeduction +
    homeLoanDeduction +
    otherDeductionsSum;

  const totalGrossIncome = inputs.grossSalary + inputs.otherIncome;
  const taxableIncome = Math.max(0, totalGrossIncome - totalDeductionsAndExemptions);

  // Slabs for Old Regime depending on age
  let basicExemptionLimit = 250000;
  if (inputs.ageGroup === 'senior60') basicExemptionLimit = 300000;
  if (inputs.ageGroup === 'superSenior80') basicExemptionLimit = 500000;

  const slabBreakdown: SlabBreakdown[] = [];
  let baseTax = 0;

  if (inputs.ageGroup === 'superSenior80') {
    // 80+ Super Senior Slabs
    const slabs = [
      { range: 'Up to ₹5,00,000', limit: 500000, rate: 0 },
      { range: '₹5,00,001 - ₹10,00,000', limit: 1000000, rate: 0.20 },
      { range: 'Above ₹10,00,000', limit: Infinity, rate: 0.30 },
    ];
    let prev = 0;
    for (const slab of slabs) {
      if (taxableIncome > prev) {
        const slabTaxable = Math.min(taxableIncome, slab.limit) - prev;
        const taxForSlab = slabTaxable * slab.rate;
        baseTax += taxForSlab;
        slabBreakdown.push({
          range: slab.range,
          rate: slab.rate * 100,
          taxableAmountInSlab: slabTaxable,
          taxForSlab: Math.round(taxForSlab),
        });
        prev = slab.limit;
      }
    }
  } else if (inputs.ageGroup === 'senior60') {
    // Senior Citizen 60-79 Slabs
    const slabs = [
      { range: 'Up to ₹3,00,000', limit: 300000, rate: 0 },
      { range: '₹3,00,001 - ₹5,00,000', limit: 500000, rate: 0.05 },
      { range: '₹5,00,001 - ₹10,00,000', limit: 1000000, rate: 0.20 },
      { range: 'Above ₹10,00,000', limit: Infinity, rate: 0.30 },
    ];
    let prev = 0;
    for (const slab of slabs) {
      if (taxableIncome > prev) {
        const slabTaxable = Math.min(taxableIncome, slab.limit) - prev;
        const taxForSlab = slabTaxable * slab.rate;
        baseTax += taxForSlab;
        slabBreakdown.push({
          range: slab.range,
          rate: slab.rate * 100,
          taxableAmountInSlab: slabTaxable,
          taxForSlab: Math.round(taxForSlab),
        });
        prev = slab.limit;
      }
    }
  } else {
    // Normal Slabs (< 60 years)
    const slabs = [
      { range: 'Up to ₹2,50,000', limit: 250000, rate: 0 },
      { range: '₹2,50,001 - ₹5,00,000', limit: 500000, rate: 0.05 },
      { range: '₹5,00,001 - ₹10,00,000', limit: 1000000, rate: 0.20 },
      { range: 'Above ₹10,00,000', limit: Infinity, rate: 0.30 },
    ];
    let prev = 0;
    for (const slab of slabs) {
      if (taxableIncome > prev) {
        const slabTaxable = Math.min(taxableIncome, slab.limit) - prev;
        const taxForSlab = slabTaxable * slab.rate;
        baseTax += taxForSlab;
        slabBreakdown.push({
          range: slab.range,
          rate: slab.rate * 100,
          taxableAmountInSlab: slabTaxable,
          taxForSlab: Math.round(taxForSlab),
        });
        prev = slab.limit;
      }
    }
  }

  // Section 87A Rebate in Old Regime (Rebate up to ₹12,500 if income <= 5 Lakhs)
  let sec87aRebate = 0;
  let taxAfterRebate = baseTax;

  if (taxableIncome <= 500000) {
    sec87aRebate = Math.min(12500, baseTax);
    taxAfterRebate = Math.max(0, baseTax - sec87aRebate);
  }

  // Surcharge
  const surchargeInfo = calculateSurcharge(taxableIncome, taxAfterRebate, 'old');
  const surchargeAmount = surchargeInfo.surchargeAmount;
  const surchargeRate = surchargeInfo.surchargeRate;

  const totalBeforeCess = taxAfterRebate + surchargeAmount;
  const cess = Math.round(totalBeforeCess * 0.04);
  const totalTaxPayable = Math.round(totalBeforeCess + cess);

  const effectiveTaxRate = totalGrossIncome > 0 ? (totalTaxPayable / totalGrossIncome) * 100 : 0;
  const netInHandAnnual = Math.max(0, totalGrossIncome - totalTaxPayable);

  return {
    regime: 'old',
    financialYear: inputs.financialYear,
    grossIncome: totalGrossIncome,
    standardDeduction,
    hraExemption,
    total80CDeduction,
    total80DDeduction,
    npsEmployeeDeduction,
    npsEmployerDeduction,
    homeLoanDeduction,
    otherDeductionsSum,
    totalDeductionsAndExemptions,
    grossTaxableIncome: totalGrossIncome,
    taxableIncome,
    slabBreakdown,
    baseTax: Math.round(baseTax),
    sec87aRebate: Math.round(sec87aRebate),
    marginalRelief87A: 0,
    taxAfterRebate: Math.round(taxAfterRebate),
    surchargeRate,
    surchargeAmount: Math.round(surchargeAmount),
    surchargeMarginalRelief: Math.round(surchargeInfo.marginalRelief),
    cess,
    totalTaxPayable,
    effectiveTaxRate: Number(effectiveTaxRate.toFixed(2)),
    monthlyTakeHome: Math.round(netInHandAnnual / 12),
    monthlyTax: Math.round(totalTaxPayable / 12),
  };
}

/**
 * Calculates Surcharge and Surcharge Marginal Relief
 */
function calculateSurcharge(
  taxableIncome: number,
  taxAfterRebate: number,
  regime: 'old' | 'new'
): { surchargeRate: number; surchargeAmount: number; marginalRelief: number } {
  if (taxableIncome <= 5000000) {
    return { surchargeRate: 0, surchargeAmount: 0, marginalRelief: 0 };
  }

  let rate = 0;
  if (taxableIncome > 5000000 && taxableIncome <= 10000000) {
    rate = 0.10;
  } else if (taxableIncome > 10000000 && taxableIncome <= 20000000) {
    rate = 0.15;
  } else if (taxableIncome > 20000000 && taxableIncome <= 50000000) {
    rate = 0.25;
  } else if (taxableIncome > 50000000) {
    rate = regime === 'new' ? 0.25 : 0.37;
  }

  let surchargeAmount = taxAfterRebate * rate;

  // Marginal relief check for surcharge
  let threshold = 5000000;
  if (taxableIncome > 10000000) threshold = 10000000;
  if (taxableIncome > 20000000) threshold = 20000000;
  if (taxableIncome > 50000000) threshold = 50000000;

  const excessIncome = taxableIncome - threshold;
  // approximate tax on threshold income
  const approxTaxOnThreshold = taxAfterRebate * (threshold / taxableIncome);
  let thresholdSurchargeRate = 0;
  if (threshold === 10000000) thresholdSurchargeRate = 0.10;
  if (threshold === 20000000) thresholdSurchargeRate = 0.15;
  if (threshold === 50000000) thresholdSurchargeRate = 0.25;

  const thresholdSurcharge = approxTaxOnThreshold * thresholdSurchargeRate;
  const maxTotalTaxAndSurcharge = approxTaxOnThreshold + thresholdSurcharge + excessIncome;
  const actualTotalTaxAndSurcharge = taxAfterRebate + surchargeAmount;

  let marginalRelief = 0;
  if (actualTotalTaxAndSurcharge > maxTotalTaxAndSurcharge) {
    marginalRelief = actualTotalTaxAndSurcharge - maxTotalTaxAndSurcharge;
    surchargeAmount = Math.max(0, surchargeAmount - marginalRelief);
  }

  return {
    surchargeRate: rate * 100,
    surchargeAmount,
    marginalRelief,
  };
}

/**
 * Calculates Breakeven Deductions required in Old Regime to match New Regime tax
 */
export function calculateBreakevenDeductions(
  inputs: TaxInputs,
  newRegimeTax: number
): number {
  if (newRegimeTax <= 0) return 0;

  const totalGrossIncome = inputs.grossSalary + inputs.otherIncome;
  
  // We use binary search to find total Old Regime deductions that yield total tax == newRegimeTax
  let minDeduction = 0;
  let maxDeduction = totalGrossIncome + 100000;
  let bestBreakeven = 0;

  for (let i = 0; i < 40; i++) {
    const midDeduction = (minDeduction + maxDeduction) / 2;
    const testTaxable = Math.max(0, totalGrossIncome - midDeduction);

    // Compute old regime tax for testTaxable
    let baseTax = 0;
    if (inputs.ageGroup === 'superSenior80') {
      if (testTaxable > 500000) {
        if (testTaxable <= 1000000) baseTax += (testTaxable - 500000) * 0.20;
        else baseTax += 500000 * 0.20 + (testTaxable - 1000000) * 0.30;
      }
    } else if (inputs.ageGroup === 'senior60') {
      if (testTaxable > 300000) {
        if (testTaxable <= 500000) baseTax += (testTaxable - 300000) * 0.05;
        else if (testTaxable <= 1000000) baseTax += 200000 * 0.05 + (testTaxable - 500000) * 0.20;
        else baseTax += 200000 * 0.05 + 500000 * 0.20 + (testTaxable - 1000000) * 0.30;
      }
    } else {
      if (testTaxable > 250000) {
        if (testTaxable <= 500000) baseTax += (testTaxable - 250000) * 0.05;
        else if (testTaxable <= 1000000) baseTax += 250000 * 0.05 + (testTaxable - 500000) * 0.20;
        else baseTax += 250000 * 0.05 + 500000 * 0.20 + (testTaxable - 1000000) * 0.30;
      }
    }

    let rebate = 0;
    if (testTaxable <= 500000) rebate = Math.min(12500, baseTax);
    const taxAfterRebate = Math.max(0, baseTax - rebate);
    const cess = taxAfterRebate * 0.04;
    const testTotalTax = taxAfterRebate + cess;

    if (testTotalTax > newRegimeTax) {
      // Need higher deductions to reduce tax
      minDeduction = midDeduction;
    } else {
      maxDeduction = midDeduction;
      bestBreakeven = midDeduction;
    }
  }

  return Math.round(bestBreakeven);
}

/**
 * Main Comparison Engine
 */
export function compareRegimes(inputs: TaxInputs): ComparisonResult {
  const oldRegime = computeOldRegimeTax(inputs);
  const newRegime = computeNewRegimeTax(inputs);

  let recommendedRegime: 'old' | 'new' | 'equal' = 'equal';
  const taxDiff = oldRegime.totalTaxPayable - newRegime.totalTaxPayable;

  if (taxDiff > 5) {
    recommendedRegime = 'new';
  } else if (taxDiff < -5) {
    recommendedRegime = 'old';
  }

  const annualSavings = Math.abs(taxDiff);
  const monthlySavings = Math.round(annualSavings / 12);

  const breakevenDeductions = calculateBreakevenDeductions(inputs, newRegime.totalTaxPayable);
  const currentDeductionsInOld = oldRegime.totalDeductionsAndExemptions;
  const deductionShortfall = Math.max(0, breakevenDeductions - currentDeductionsInOld);

  return {
    oldRegime,
    newRegime,
    recommendedRegime,
    taxDifference: Math.abs(taxDiff),
    annualSavings,
    monthlySavings,
    breakevenDeductions,
    currentDeductionsInOld,
    deductionShortfall,
  };
}
