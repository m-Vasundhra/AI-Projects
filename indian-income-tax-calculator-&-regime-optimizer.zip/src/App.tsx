import React, { useState, useMemo } from 'react';
import { TaxInputs, FinancialYear } from './types';
import { PRESET_PROFILES, PresetProfile } from './data/presets';
import { compareRegimes } from './utils/taxCalculator';

import { Header } from './components/Header';
import { WinnerBanner } from './components/WinnerBanner';
import { IncomeForm } from './components/IncomeForm';
import { DeductionsForm } from './components/DeductionsForm';
import { ComparisonSummary } from './components/ComparisonSummary';
import { BreakevenAnalysis } from './components/BreakevenAnalysis';
import { TaxSlabBreakdown } from './components/TaxSlabBreakdown';
import { AiTaxAdvisor } from './components/AiTaxAdvisor';
import { TaxSlabGuide } from './components/TaxSlabGuide';
import { HraCalculatorModal } from './components/HraCalculatorModal';
import { TaxReportModal } from './components/TaxReportModal';

import { Calculator, Scale, Target, Bot, FileText, HelpCircle, ArrowRight } from 'lucide-react';

export default function App() {
  const [financialYear, setFinancialYear] = useState<FinancialYear>('2024-25');
  const [activeTab, setActiveTab] = useState<'calculator' | 'guide'>('calculator');
  const [subTab, setSubTab] = useState<'inputs' | 'comparison' | 'breakeven' | 'slabs' | 'ai'>('inputs');

  const [isHraModalOpen, setIsHraModalOpen] = useState(false);
  const [isReportModalOpen, setIsReportModalOpen] = useState(false);

  // Initial tax inputs (Default IT Pro ₹12L)
  const [inputs, setInputs] = useState<TaxInputs>({
    financialYear: '2024-25',
    ageGroup: 'below60',
    employmentType: 'salaried',
    grossSalary: 1200000,
    basicSalary: 600000,
    hraReceived: 240000,
    rentPaid: 216000,
    isMetro: true,
    specialAllowance: 360000,
    otherSalaryAllowances: 0,
    ltaReceived: 0,
    homeLoanInterest: 0,
    otherIncome: 25000,
    sec80C: 150000,
    sec80D_self: 25000,
    sec80D_parents: 25000,
    sec80CCD1B: 50000,
    sec80CCD2: 0,
    sec80TTA: 10000,
    sec80E: 0,
    sec80G: 0,
    professionalTax: 2500,
    otherDeductions: 0,
  });

  const handleInputChange = (key: keyof TaxInputs, value: any) => {
    setInputs((prev) => ({ ...prev, [key]: value }));
  };

  const handleYearSelect = (year: FinancialYear) => {
    setFinancialYear(year);
    setInputs((prev) => ({ ...prev, financialYear: year }));
  };

  const handlePresetSelect = (preset: PresetProfile) => {
    setInputs({ ...preset.inputs, financialYear });
  };

  const handleApplyHra = (hra: number, rent: number, isMetro: boolean) => {
    setInputs((prev) => ({
      ...prev,
      hraReceived: hra,
      rentPaid: rent,
      isMetro: isMetro,
    }));
  };

  // Re-calculate tax results memoized
  const comparison = useMemo(() => {
    return compareRegimes(inputs);
  }, [inputs]);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-emerald-500 selection:text-slate-950 pb-16">
      
      {/* Navigation Header */}
      <Header
        financialYear={financialYear}
        onSelectYear={handleYearSelect}
        onSelectPreset={handlePresetSelect}
        onOpenHraModal={() => setIsHraModalOpen(true)}
        onOpenReportModal={() => setIsReportModalOpen(true)}
        activeTab={activeTab}
        setActiveTab={setActiveTab}
      />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 space-y-6">
        
        {activeTab === 'calculator' ? (
          <>
            {/* Top Highlight Winner Banner */}
            <WinnerBanner comparison={comparison} />

            {/* Navigation Tabs for Calculator */}
            <div className="flex items-center space-x-1 sm:space-x-2 border-b border-slate-800 overflow-x-auto pb-1 scrollbar-none">
              <button
                onClick={() => setSubTab('inputs')}
                className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-t-xl font-semibold text-xs transition-all border-b-2 ${
                  subTab === 'inputs'
                    ? 'border-emerald-500 bg-slate-900 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Calculator className="w-4 h-4" />
                <span>Salary & Deductions Input</span>
              </button>

              <button
                onClick={() => setSubTab('comparison')}
                className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-t-xl font-semibold text-xs transition-all border-b-2 ${
                  subTab === 'comparison'
                    ? 'border-emerald-500 bg-slate-900 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Scale className="w-4 h-4" />
                <span>Comparative Table</span>
              </button>

              <button
                onClick={() => setSubTab('breakeven')}
                className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-t-xl font-semibold text-xs transition-all border-b-2 ${
                  subTab === 'breakeven'
                    ? 'border-emerald-500 bg-slate-900 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Target className="w-4 h-4" />
                <span>Breakeven "Magic Number"</span>
              </button>

              <button
                onClick={() => setSubTab('slabs')}
                className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-t-xl font-semibold text-xs transition-all border-b-2 ${
                  subTab === 'slabs'
                    ? 'border-emerald-500 bg-slate-900 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <FileText className="w-4 h-4" />
                <span>Step Slabs</span>
              </button>

              <button
                onClick={() => setSubTab('ai')}
                className={`flex items-center space-x-1.5 px-4 py-2.5 rounded-t-xl font-semibold text-xs transition-all border-b-2 ${
                  subTab === 'ai'
                    ? 'border-emerald-500 bg-slate-900 text-emerald-400'
                    : 'border-transparent text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Bot className="w-4 h-4 text-emerald-400" />
                <span className="flex items-center space-x-1">
                  <span>AI CA Advice</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                </span>
              </button>
            </div>

            {/* SubTab Views */}
            <div className="space-y-6">
              {subTab === 'inputs' && (
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <IncomeForm
                    inputs={inputs}
                    onChange={handleInputChange}
                    onOpenHraCalc={() => setIsHraModalOpen(true)}
                  />
                  <DeductionsForm inputs={inputs} onChange={handleInputChange} />
                </div>
              )}

              {subTab === 'comparison' && (
                <ComparisonSummary comparison={comparison} />
              )}

              {subTab === 'breakeven' && (
                <BreakevenAnalysis comparison={comparison} />
              )}

              {subTab === 'slabs' && (
                <TaxSlabBreakdown
                  newRegime={comparison.newRegime}
                  oldRegime={comparison.oldRegime}
                />
              )}

              {subTab === 'ai' && (
                <AiTaxAdvisor
                  inputs={inputs}
                  oldRegime={comparison.oldRegime}
                  newRegime={comparison.newRegime}
                />
              )}
            </div>

            {/* Quick Action Footer Bar */}
            <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 flex flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-xs text-slate-400">
                <span className="font-semibold text-white">Need a copy of your tax computation?</span> Download or print a clean summary statement.
              </div>
              <div className="flex items-center space-x-3">
                <button
                  onClick={() => setIsReportModalOpen(true)}
                  className="bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs px-4 py-2 rounded-xl transition-all shadow flex items-center space-x-1.5"
                >
                  <FileText className="w-4 h-4" />
                  <span>View Printable Tax Report</span>
                </button>
              </div>
            </div>
          </>
        ) : (
          /* Guide Tab View */
          <TaxSlabGuide />
        )}

      </main>

      {/* Modals */}
      <HraCalculatorModal
        isOpen={isHraModalOpen}
        onClose={() => setIsHraModalOpen(false)}
        basicSalary={inputs.basicSalary}
        hraReceived={inputs.hraReceived}
        rentPaid={inputs.rentPaid}
        isMetro={inputs.isMetro}
        onApplyHra={handleApplyHra}
      />

      <TaxReportModal
        isOpen={isReportModalOpen}
        onClose={() => setIsReportModalOpen(false)}
        comparison={comparison}
      />

    </div>
  );
}
